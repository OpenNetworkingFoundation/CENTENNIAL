package framework;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import gui.SchedulerPanel;
import operations.LoginToNodes;
import operations.WriteToFile;
import resources.Repository;

public class FetchLTPs extends Thread{
	
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	Map<String,Set<String>> NodeDetails = new HashMap<String,Set<String>>();
	String selectedNode;
	public FetchLTPs(String selectedNode, Map<String,Set<String>> NodeDetails) {
		super();
		this.selectedNode = selectedNode;
		this.NodeDetails = NodeDetails;
		
	}
	public Runnable task = () -> {
		
		try { 
			//SchedulerPanel.ltpFetchCount =0;
			LocalDateTime now = LocalDateTime.now();
			System.out.println("start time of "+  selectedNode +" "+ dtf.format(now));
			if(NodeDetails.containsKey(selectedNode))
			{
				SchedulerPanel.ltpFetchCount++;
				Set<String> LTPlist = NodeDetails.get(selectedNode);
				Iterator<String> iter = LTPlist.iterator();
				while(iter.hasNext())
				{
					String Node = iter.next();
					if(Node.contains("air-interface")) {
						String[] Node1 = Node.split("&");
						SchedulerPanel.fetchAll_airInterface.add(Node1[0]);
					}
					if(Node.contains("ethernet-container")) {
						String[] Node1 = Node.split("&");
						SchedulerPanel.fetchAll_ethernetInterface.add(Node1[0]);
					}
				}
			}
			else {
				
				//If its not there in the file , then load it 
				WriteToFile writer = new WriteToFile(SchedulerPanel.getUsersHomeDir()+ File.separator+"PerformanceTool"+ File.separator +"Controller_LTP_Details");					
				new LoginToNodes(selectedNode,"fetchAll"); 
				if(Repository.MapLogicalProtocolMap.containsKey(selectedNode))
				{  
					SchedulerPanel.ltpFetchCount++;
					Map<String,String> LTPs = Repository.MapLogicalProtocolMap.get(this.selectedNode);
					Set<Map.Entry<String, String>> entryMap = LTPs.entrySet();
			    	Iterator<Map.Entry<String, String>> entryMapIterator = entryMap.iterator();
			    	while(entryMapIterator.hasNext())
			    	{
				    	Map.Entry<String, String> entry = entryMapIterator.next();
			    		if(entry.getValue().contains("air-interface"))
			    		{
			    			SchedulerPanel.fetchAll_airInterface.add(selectedNode + ":::" + entry.getKey());
			    			String LPValue = Repository.MapLTP_LPMap.get(selectedNode).get(entry.getKey());
			    			writer.write(selectedNode + ":::" + entry.getKey()+ ":::" +entry.getValue()+ ":::" + LPValue + "\n");
			    		}
			    		if(entry.getValue().contains("ethernet-container"))
			    		{
			    			SchedulerPanel.fetchAll_ethernetInterface.add(selectedNode + ":::" + entry.getKey());
			    			String LPValue = Repository.MapLTP_LPMap.get(selectedNode).get(entry.getKey());
			    			writer.write(selectedNode + ":::" + entry.getKey()+ ":::" +entry.getValue()+ ":::" + LPValue + "\n");
			    		}
			    	}    			    	
				}
			writer.close();
			}
			now = LocalDateTime.now();
			System.out.println("end time of "+ selectedNode +" "+ dtf.format(now));
			
		}
		catch(Exception e) {
		 System.out.println("error in thread: \n"+ e.getMessage()); 
		} 
		
	};
}
	