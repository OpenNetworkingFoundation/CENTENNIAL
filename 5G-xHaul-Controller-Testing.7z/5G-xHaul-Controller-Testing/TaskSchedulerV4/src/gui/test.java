package gui;

public class test {
	
	public static void main(String[] args)
	{
		int i = 0;
		while(i<1000)
		{
			System.out.println(i);
			i++;
		}
	}

}
