package resources;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Repository {
	
	public static Set<String> NodeList = new TreeSet<String>();
	public static Map<String,Map<String,String>> MapLogicalProtocolMap = new HashMap<String, Map<String,String>>();
	public static Map<String,Map<String,String>> MapLTP_LPMap = new HashMap<String, Map<String,String>>();
	public static Map<String,String> LogicalProtocolMap = new HashMap<String, String>();
	public static Map<String,String> LTP_LPMap = new HashMap<String, String>();

}
