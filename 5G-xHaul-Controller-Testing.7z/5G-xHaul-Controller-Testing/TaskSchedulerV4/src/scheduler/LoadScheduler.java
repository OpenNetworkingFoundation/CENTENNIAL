package scheduler;

public interface LoadScheduler {

}
