'use strict';

var utils = require('../utils/writer.js');
var BasicServices = require('../service/BasicServicesService');

module.exports.informAboutApplication = function informAboutApplication (req, res, next) {
  BasicServices.informAboutApplication()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.informAboutApplicationInGenericRepresentation = function informAboutApplicationInGenericRepresentation (req, res, next) {
  BasicServices.informAboutApplicationInGenericRepresentation()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.informAboutReleaseHistory = function informAboutReleaseHistory (req, res, next) {
  BasicServices.informAboutReleaseHistory()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.informAboutReleaseHistoryInGenericRepresentation = function informAboutReleaseHistoryInGenericRepresentation (req, res, next) {
  BasicServices.informAboutReleaseHistoryInGenericRepresentation()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
