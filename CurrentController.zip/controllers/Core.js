'use strict';

var utils = require('../utils/writer.js');
var Core = require('../service/CoreService');

module.exports.getControlConstruct = function getControlConstruct (req, res, next, fields) {
  Core.getControlConstruct(fields)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
