'use strict';

var utils = require('../utils/writer.js');
var IndividualServices = require('../service/IndividualServicesService');

module.exports.provideCurrentController = function provideCurrentController (req, res, next) {
  IndividualServices.provideCurrentController()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.provideCurrentControllerInGenericRepresentation = function provideCurrentControllerInGenericRepresentation (req, res, next) {
  IndividualServices.provideCurrentControllerInGenericRepresentation()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startApplicationInGenericRepresentation = function startApplicationInGenericRepresentation (req, res, next) {
  IndividualServices.startApplicationInGenericRepresentation()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
