'use strict';

var utils = require('../utils/writer.js');
var OperationServer = require('../service/OperationServerService');

module.exports.getOperationServerCurrentController = function getOperationServerCurrentController (req, res, next, uuid, lid) {
  OperationServer.getOperationServerCurrentController(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getOperationServerLifeCycleState = function getOperationServerLifeCycleState (req, res, next, uuid, lid) {
  OperationServer.getOperationServerLifeCycleState(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getOperationServerOperationKey = function getOperationServerOperationKey (req, res, next, uuid, lid) {
  OperationServer.getOperationServerOperationKey(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getOperationServerOperationName = function getOperationServerOperationName (req, res, next, uuid, lid) {
  OperationServer.getOperationServerOperationName(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putOperationServerCurrentController = function putOperationServerCurrentController (req, res, next, body, uuid, lid) {
  OperationServer.putOperationServerCurrentController(body, uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putOperationServerLifeCycleState = function putOperationServerLifeCycleState (req, res, next, body, uuid, lid) {
  OperationServer.putOperationServerLifeCycleState(body, uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
