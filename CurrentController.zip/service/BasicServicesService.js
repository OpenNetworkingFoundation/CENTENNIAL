'use strict';


/**
 * Returns administrative information
 *
 * returns inline_response_200_3
 **/
exports.informAboutApplication = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "applicationName" : "CurrentController",
  "applicationPurpose" : "Provides first part of the RESTCONF request to other applications.",
  "dataUpdatePeriod" : "manual",
  "lifeCycleState" : "Deprecated",
  "ownerName" : "Thorsten Heinze",
  "ownerEmailAddress" : "Thorsten.Heinze@telefonica.com"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns administrative information for generic representation
 *
 * returns List
 **/
exports.informAboutApplicationInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  }, {
    "fieldName" : "applicationPurpose",
    "value" : "Provides first part of the RESTCONF request to other applications.",
    "datatype" : "String"
  }, {
    "fieldName" : "dataUpdatePeriod",
    "value" : "manual",
    "datatype" : "String"
  }, {
    "fieldName" : "lifeCycleState",
    "value" : "Deprecated",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerName",
    "value" : "Thorsten Heinze",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerEmailAddress",
    "value" : "Thorsten.Heinze@telefonica.com",
    "datatype" : "String"
  } ],
  "consequentActionList" : [ {
    "label" : "Release History",
    "request" : "/v1/informAboutReleaseHistoryInGenericRepresentation"
  }, {
    "label" : "API Documentation",
    "request" : "/v1/informAboutApi"
  } ]
}, {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  }, {
    "fieldName" : "applicationPurpose",
    "value" : "Provides first part of the RESTCONF request to other applications.",
    "datatype" : "String"
  }, {
    "fieldName" : "dataUpdatePeriod",
    "value" : "manual",
    "datatype" : "String"
  }, {
    "fieldName" : "lifeCycleState",
    "value" : "Deprecated",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerName",
    "value" : "Thorsten Heinze",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerEmailAddress",
    "value" : "Thorsten.Heinze@telefonica.com",
    "datatype" : "String"
  } ],
  "consequentActionList" : [ {
    "label" : "Release History",
    "request" : "/v1/informAboutReleaseHistoryInGenericRepresentation"
  }, {
    "label" : "API Documentation",
    "request" : "/v1/informAboutApi"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns release history
 *
 * returns List
 **/
exports.informAboutReleaseHistory = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "revisionNumber" : "0.0.1",
  "releaseDate" : "29.04.2021",
  "changes" : "Initial version"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns release history for generic representation
 *
 * returns List
 **/
exports.informAboutReleaseHistoryInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "revisionNumber",
    "value" : "0.0.1",
    "datatype" : "String"
  }, {
    "fieldName" : "releaseDate",
    "value" : "29.04.2021",
    "datatype" : "String"
  }, {
    "fieldName" : "changes",
    "value" : "Initial version",
    "datatype" : "String"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

