'use strict';


/**
 * Returns IP address of the server
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_13
 **/
exports.getTcpServerLocalAddress = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "tcp-server-interface-1-0:local-address" : {
    "ipv-4-address" : "0.0.0.0",
    "ipv-6-address" : "0:0:0:0:0:0:0:0"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns TCP port of the server
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_14
 **/
exports.getTcpServerLocalPort = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "tcp-server-interface-1-0:local-port" : 0
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Documents IP address of the server
 *
 * body Body_2 
 * uuid String 
 * lid String 
 * no response value expected for this operation
 **/
exports.putTcpServerLocalAddress = function(body,uuid,lid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Documents TCP port of the server
 *
 * body Body_3 
 * uuid String 
 * lid String 
 * no response value expected for this operation
 **/
exports.putTcpServerLocalPort = function(body,uuid,lid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

