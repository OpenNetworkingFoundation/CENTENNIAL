package rmon;
/*
 * @author : Prathiba Jeevan
 * purpose : Set the link name 
 * step 1 : Read the input details from the file LinkDetails
 * step 2 :	Load the LTP LP details database for the given nodes 
 * step 3 : Load the equipment and connector database for the given nodes
 * step 4 : perform get operation and view the already existing value
 * step 5 : perform set operation with the new value
 * step 6 : perform get operation and view the new changed value
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.common.Result;
import rmon.database.MyComData;
import rmon.database.ServerClientLTPs;
import rmon.database.WriteToFile;
import rmon.logger.*;

public class LinkName {
	
	
	public static Set<String> nodes = new HashSet<String>();
	
		
	public static void main(String[] args)
	{
		loadConfigFile();
		basicFileSetup();
		MyComData.loadFromInput(nodes);
		startProcess();
	}
	
	
	public static void loadConfigFile()
	{
		try {
		Properties config = new Properties();
		FileInputStream configFile = new FileInputStream(System.getProperty("user.dir") + "/Config.properties");
		config.load(configFile);
		// load the properties and store in configuration
		new Configuration(config);
		}catch(FileNotFoundException ex)
		{
			Log.Error("File config.properties is not available in the user directory location");
			Log.Error(ex);
		}catch(IOException ex)
		{
			Log.Error("Issues in reading/loading the config.properties file");
			Log.Error(ex);
		}
	}
	
	
	
	public static void basicFileSetup()
	{
		File baseDirectory = new File(getUsersHomeDir());
		if (!baseDirectory.exists()) {
			baseDirectory.mkdir();
		}
		Configuration.InputPath = getUsersHomeDir() + File.separator + "Input";
		Configuration.DBbasePath = getUsersHomeDir() + File.separator + "DataBase";
		Configuration.DBPath = Configuration.DBbasePath + File.separator + Configuration.ipAddress.replace(".", "_");
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
		Configuration.ReportResult = Configuration.RmonReportDir + File.separator + "ReportResult" + "_" + formatter.format(new Date())+".csv";
		Configuration.output = Configuration.RmonBasePath + File.separator + "output" +".csv";
		File InputPath = new File(Configuration.InputPath);
		File DBbasePath = new File(Configuration.DBbasePath);
		File DataBasePath = new File(Configuration.DBPath);
		
		if (!InputPath.exists()) {
			InputPath.mkdir();
		}
		if (!DBbasePath.exists()) {
			DBbasePath.mkdir();
		}		
		if (!DataBasePath.exists()) {
			DataBasePath.mkdir();
		}	
	}
	
	public static void deleteOutput()
	{
		File newFile = new File(Configuration.output);
		if(newFile.exists())
		{
			try {
			Files.delete(Paths.get(Configuration.output));
			}catch(Exception ex)
			{
			Log.Error("Error while deleting the file "+Configuration.output);
			Log.Error(ex);
			}
		}
	}
	
	public static void createOutput()
	{
		WriteToFile reportOutput = new WriteToFile(Configuration.output);
		reportOutput.writeWithoutClose(Configuration.airInterfaceReport);
		reportOutput.writeWithoutClose(Configuration.StatistisReport);
		reportOutput.writeWithoutClose(Configuration.ReportResult);
		reportOutput.writeAndClose();
	}
	
	public static void startProcess()
	{
		Iterator<String> iterator = nodes.iterator();
		while(iterator.hasNext())
		{
			String nodeId = iterator.next();
			LoadDatabase loadDatabase = new LoadDatabase(nodeId);
			loadDatabase.loadFromDataBase();
		}
		SetExternalLabel.setExternalLabel();
	}
	
	public static String getUsersHomeDir() {
		String users_home = System.getProperty("user.home");		
		return users_home.replace("\\", "/")+ File.separator + "SDN"; // to support all platforms.
	}
	
	
	
}
