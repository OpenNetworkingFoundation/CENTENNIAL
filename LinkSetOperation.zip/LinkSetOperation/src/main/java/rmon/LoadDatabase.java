package rmon;


import rmon.database.Equipment;
import rmon.database.LtpAugment;
import rmon.database.ServerClientLTPs;

public class LoadDatabase extends Thread{
	
	public String DBStatus = new String();
	public String nodeId = new String();
	
	public LoadDatabase(String nodeId)
	{
		this.nodeId = nodeId;
	}
	

	public void loadFromDataBase() {		
		ServerClientLTPs.loadFromDB(nodeId,this);
		LtpAugment.loadFromDB(nodeId,this);
		Equipment.loadFromDB(nodeId,this);
	}
}
