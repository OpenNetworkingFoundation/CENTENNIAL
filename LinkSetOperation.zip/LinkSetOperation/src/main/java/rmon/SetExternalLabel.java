package rmon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import rmon.common.RestOperations;
import rmon.common.RestPutOperation;
import rmon.database.Connector;
import rmon.database.DataBase;
import rmon.database.LtpAugment;

/**
 * @author Prathiba Jeevan Steps : 1) For each entry in the mycomm datalist , 2)
 *         for the connector name , get the equivalent LTP name 3) set the link
 *         name
 *
 */

public class SetExternalLabel {

	public static String tab = "\t";

	public static void setExternalLabel() {
		Map<String, String> myComData = DataBase.myCommData;
		Iterator<Map.Entry<String, String>> entrySet = myComData.entrySet().iterator();
		while (entrySet.hasNext()) {
			Map.Entry<String, String> entry = entrySet.next();
			String key = entry.getKey();
			String linkName = entry.getValue();
			String nodeId = key.split(":::")[0];
			String connector = key.split(":::")[1];
			String uuid = getUUidFromConnector(nodeId, connector);
			if (uuid != null) {
				String newValue = new String();
				String oldValue = RestOperations.getExternallableAttribute(nodeId, uuid);
				boolean result = RestPutOperation.putOperation(nodeId, uuid, linkName);
				if (result == true) {
					newValue = RestOperations.getExternallableAttribute(nodeId, uuid);
					if (newValue.equals(linkName)) {
						System.out.println(nodeId + tab + connector + tab + "pass" + tab + oldValue + tab + newValue
								+ tab + linkName);
					} else {
						System.out.println(nodeId + tab + connector + tab + "fail" + tab + oldValue + tab + newValue
								+ tab + linkName + tab + "putoperation was successful,but value not changing");
					}
				} else {
					System.out.println(nodeId + tab + connector + tab + "fail" + tab + oldValue + tab + newValue + tab
							+ linkName + tab + "put operation failed");
				}
			} else {
				System.out.println(nodeId + tab + connector + tab + "fail" + tab + "" + tab + "" + tab + linkName + tab
						+ "No connector name matching");
			}
		}
	}

	/*
	 * get the mapped connector local id get the LTP agument iterator match the
	 * local id and the ltp-augment connector id and get the uuid
	 * 
	 */
	public static String getUUidFromConnector(String nodeId, String connectorName) {

		ArrayList<Connector> connectorsArray = DataBase.connectors.get(nodeId);
		if (connectorsArray != null) {
			Iterator<Connector> connIterator = connectorsArray.iterator();
			while (connIterator.hasNext()) {
				Connector connect = connIterator.next();
				if (connectorName.equals(connect.name)) {
					String local_id = connect.uuid;
					ArrayList<LtpAugment> LtpAugmentArray = DataBase.ltpAugment.get(nodeId);
					if (LtpAugmentArray != null) {
						Iterator<LtpAugment> iterator = LtpAugmentArray.iterator();
						while (iterator.hasNext()) {
							LtpAugment LtpAugments = iterator.next();
							if (LtpAugments.connectors.equals(local_id)) {
								return LtpAugments.uuid;
							}
						}
					}

				}
			}
		}

		return null;
	}

}
