package rmon.common;

import java.io.FileInputStream;
import java.util.Properties;

import rmon.database.Vendor;
import rmon.logger.Log;

public class Configuration {
	
	public static String userName = new String();
	public static String password = new String();
	public static String ipAddress = new String();
	public static int port = 8181;
	public static String Nodeall = new String();
	public static String NodeName = new String();
	public static String Node_Config = new String();
	public static long frequency;
    public static int iteration;
	public static String LTPResync = new String();
	public static String VendorResync = new String();
	public static String EquipmentResync = new String();
	public static String InputPath = new String();
    public static String DBbasePath = new String();
    public static String RmonBasePath = new String();
    public static String DBPath = new String();
    public static String RmonReportDir = new String();
    public static String RmonReportPath = new String();
    public static String airInterfaceReport = new String();
    public static String StatistisReport = new String();
    public static String output = new String();
    public static String ReportResult = new String();
    public static String ReportOutput = new String();
    public static String airInterface = "air-interface-2-0:LAYER_PROTOCOL_NAME_TYPE_AIR_LAYER";
    public static String wireInterface = "wire-interface-2-0:LAYER_PROTOCOL_NAME_TYPE_WIRE_LAYER";
	public static String capacityCalculation = new String();
	public static String statisticsCalculation = new String();
	public Configuration(Properties config)
	{
		try
		{
			userName = config.getProperty("Controller.username");
			password = config.getProperty("Controller.password");
			ipAddress = config.getProperty("Controller.ip");
			port = new Integer(config.getProperty("Controller.port"));
			Nodeall = config.getProperty("Node.all");
			NodeName = config.getProperty("Node.Names");
			Node_Config = config.getProperty("Node.Config");
			
			LTPResync = config.getProperty("LTP.resync");
			VendorResync = config.getProperty("Vendor.resync");
			EquipmentResync = config.getProperty("equipment.resync");
			String[] vendorTypes = config.getProperty("Vendor.types").split(",");
			for(int i=0;i<vendorTypes.length;i++)
			{
				Vendor.vendorTypes.add(vendorTypes[i]);
			}

		}catch(Exception ex)
		{
			Log.Error("Error in reading the properties values while loading it to configuration");
			Log.Error(ex);
		}
	}

}
