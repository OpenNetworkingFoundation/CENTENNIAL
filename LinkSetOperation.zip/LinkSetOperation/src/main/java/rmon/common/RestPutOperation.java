package rmon.common;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;

import rmon.logger.Log;

public class RestPutOperation {
	
	public static boolean putOperation(String nodeId, String uuid, String linkName)
	{
		String url = RestUrls.putExternalLabel.replace("<<nodeId>>", nodeId).replace("<<uuid>>", uuid);
		HttpHost targetHost = new HttpHost(Configuration.ipAddress, Configuration.port, "http");
    	CredentialsProvider credsProvider = new BasicCredentialsProvider();
    	credsProvider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(Configuration.userName, Configuration.password));
    	
    	//defining basic authentication
    	AuthCache authCache = new BasicAuthCache();
    	authCache.put(targetHost, new BasicScheme());
    	 
    	// Add AuthCache to the execution context
    	HttpClientContext context = HttpClientContext.create();
    	context.setCredentialsProvider(credsProvider);
    	context.setAuthCache(authCache);
    	HttpClient client = HttpClientBuilder.create().build();    	
    	
    	try {
            HttpPut httpPut = new HttpPut(url);
            httpPut.setHeader("Accept", "application/json");
    		httpPut.setHeader("Content-type", "application/json");        	
        	String requestBody = "{\n\""+ "core-model-1-4:value" +"\": "+ "\"" + linkName + "\"" +"\n}";
    		StringEntity stringEntity = new StringEntity(requestBody);
    		httpPut.setEntity(stringEntity);    		
            HttpResponse response = client.execute(httpPut,context);
            if (response == null) {
    			Log.Error("Restcall didnt executed successfully for the url " + url);
    			return false;
    		}
            int responseCode = response.getStatusLine().getStatusCode();
    		if (response != null && (responseCode != 204 && responseCode != 200 )) {
    		Log.Error("response code is not 200/204 for the url " + url );
    		return false;
    		} 
    	}
        catch(Exception ex)
        {
        	Log.Error("Exception in executing the url " + url );
        }
        
		return true;
    }
	
}