package rmon.common;

import java.util.ArrayList;
import java.util.Iterator;

import rmon.database.WriteToFile;

public class Result {
	
	public static int connected = 0;
	public static int notConnected = 0;
	public static ArrayList<String> connectedList = new ArrayList<String>();
	public static ArrayList<String> notConnectedList = new ArrayList<String>();
	public static String tab = "\t";
	
	public static void updateResult()
	{
		WriteToFile statisticsWrite = new WriteToFile(Configuration.ReportResult);		
		statisticsWrite.writeWithoutClose("number of connected nodes" + tab + connected);		
		statisticsWrite.writeWithoutClose("list of connected nodes" + tab + getListAsString(connectedList));
		statisticsWrite.writeWithoutClose("number of not Connected nodes" + tab + notConnected);	
		statisticsWrite.writeWithoutClose("list of not connected nodes" + tab + getListAsString(notConnectedList));
		statisticsWrite.writeAndClose();
	}
	
	public static String getListAsString(ArrayList<String> list)
	{
		String output = new String();
		Iterator<String> iterator = list.iterator();
		while(iterator.hasNext())
		{
			if(output.isEmpty())
			{
			output = iterator.next();
			}else {
			output = output + ";" +iterator.next() ; 
			}
		}
		return output;
	}
	
}
