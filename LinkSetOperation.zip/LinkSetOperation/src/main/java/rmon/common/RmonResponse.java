package rmon.common;

import org.json.JSONArray;
import org.json.JSONObject;

public class RmonResponse {
	
	public Object response;
	public String result;
	public int responseCode;
	
	public RmonResponse(String response,int responseCode,String result)
	{
		this.result = result;
		this.response = response;
		this.responseCode = responseCode;
	}
	
	public RmonResponse(JSONArray response,int responseCode,String result)
	{
		this.result = result;
		this.response = response;
		this.responseCode = responseCode;
	}
	
	public RmonResponse(JSONObject response,int responseCode,String result)
	{
		this.result = result;
		this.response = response;
		this.responseCode = responseCode;
	}

}
