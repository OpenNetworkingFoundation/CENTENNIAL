package rmon.database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DataBase {
	
	public static Map<String, ArrayList<LTPLPs>> LTPLPs = new HashMap<String, ArrayList<LTPLPs>>();
	public static Map<String, ArrayList<ServerClientLTPs>> ServerClientLTPs = new HashMap<String, ArrayList<ServerClientLTPs>>();
	public static Map<String,String> vendors = new HashMap<String,String>();
	public static Map<String,ArrayList<LtpAugment>> ltpAugment = new HashMap<String,ArrayList<LtpAugment>>();
	public static Map<String,ArrayList<Equipment>> equipments = new HashMap<String,ArrayList<Equipment>>();
	public static Map<String,ArrayList<Connector>> connectors = new HashMap<String,ArrayList<Connector>>();
	public static Map<String, Map<String, String>> MapWANConnectedLayers = new HashMap<String, Map<String, String>>();
	public static Map<String, Map<String, String>> MapLANConnectedLayers = new HashMap<String, Map<String, String>>();
	public static Map<String,String> myCommData = new HashMap<String,String>();
	
	public static synchronized void setLTPLPs(String nodeId,ArrayList<LTPLPs> LTPs) {
		LTPLPs.put(nodeId,LTPs);
	}
	public static synchronized void setServerClientLTPs(String nodeId,ArrayList<ServerClientLTPs> LTPArray) {
		ServerClientLTPs.put(nodeId, LTPArray);
	}
	public static synchronized void setVendors(String nodeId, String manufacturerName) {
		vendors.put(nodeId, manufacturerName);
	}
	public static synchronized void setLtpAugment(String nodeId, ArrayList<LtpAugment> LtpAugmentArray) {
		ltpAugment.put(nodeId, LtpAugmentArray);
	}
	public static synchronized void setEquipments(String nodeId, ArrayList<Equipment> equipmentDetails) {
		equipments.put(nodeId, equipmentDetails);
	}
	public static synchronized void setConnectors(String nodeId, ArrayList<Connector> connectorArray) {
		connectors.put(nodeId, connectorArray);
	}
	public static synchronized void setMapWANConnectedLayers(String nodeId, Map<String, String> MapWANConnectedLayer) {
		MapWANConnectedLayers.put(nodeId, MapWANConnectedLayer);
	}
	public static synchronized void setMapLANConnectedLayers(String nodeId, Map<String, String> MapLANConnectedLayer) {
		MapLANConnectedLayers.put(nodeId, MapLANConnectedLayer);
	}
	public static synchronized void setMyCommData(String nodeId, String linkName) {
		myCommData.put(nodeId, linkName);
	}
	
	
}
