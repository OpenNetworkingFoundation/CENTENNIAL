package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.logger.Log;

/*
 * Read from the file {user.dir}/Rmon
 * Format : NodeId:::uuid:::layerProtocolName:::localId
 */

public class LTPLPs {
	
	public String nodeId;
	public String uuid;
	public String lpId;
	public String protocolName;
	public static String file = Configuration.DBPath + File.separator + "LTPLPs";
	
	public LTPLPs(String nodeId, String uuid, String protocolName,String lpId ) {
		this.nodeId = nodeId;
		this.uuid = uuid;
		this.protocolName = protocolName;
		this.lpId = lpId;
	}

	public static void loadFromDB(String nodeId)
	{
		ArrayList<LTPLPs> LTPs = new ArrayList<LTPLPs>();
		try {			
			File ltpFile = new File(file);			
			if (ltpFile.exists()) {
				
				Scanner scan = new Scanner(ltpFile);
				while (scan.hasNextLine()) {
					String line = scan.nextLine();
					String[] details = line.split(":::");
					if (details[0].equals(nodeId)) {
						String uuid = details[1];
						String ProtocolName = details[2];
						String local_id = details[3];
						LTPLPs ltpLps = new LTPLPs(nodeId,uuid,ProtocolName,local_id);
						LTPs.add(ltpLps);
					}
				}
				scan.close();				
			}
		} catch (Exception ex) {
			Log.Error("exception in retrieving LTP details from file" + nodeId);
			Log.Error(ex);
		}
		if(!LTPs.isEmpty())
		{
		DataBase.setLTPLPs(nodeId,LTPs);
		}else
		{
		loadFromController(nodeId);
		}
	}
	
	public static void loadFromController(String nodeId)
	{
		JSONArray response = RestOperations.getLogicalTerminationPoint(nodeId);
		if(response!=null) {
		loadFromResponse(nodeId,response);
		}
	}
	
	public static void loadFromResponse(String nodeId,JSONArray response)
	{
		ArrayList<LTPLPs> LTPs = new ArrayList<LTPLPs>();
		
		for (int i = 0; i < response.length(); i++) {
			WriteToFile ltpDetailsWriter = new WriteToFile(file);
			JSONObject json = response.getJSONObject(i);
			String uuid = json.getString("uuid");
			JSONArray Protocol = json.getJSONArray("layer-protocol");
			String ProtocolName = "";
			String local_id = "";
			if (Protocol.getJSONObject(0).has("layer-protocol-name")) {
				ProtocolName = Protocol.getJSONObject(0).getString("layer-protocol-name");
			}
			if (Protocol.getJSONObject(0).has("local-id")) {
				local_id = Protocol.getJSONObject(0).getString("local-id");
			} 
			LTPLPs ltpLps = new LTPLPs(nodeId,uuid,ProtocolName,local_id);
			LTPs.add(ltpLps);
			ltpDetailsWriter.write(nodeId + ":::" + uuid + ":::" + ProtocolName + ":::" + local_id );
		}
		DataBase.setLTPLPs(nodeId,LTPs);
	}
	
	public static ArrayList<String> getLTPs(String nodeId)
	{
		ArrayList<String> LTPs = new ArrayList<String>();
		ArrayList<LTPLPs> LTPLPs = DataBase.LTPLPs.get(nodeId);
		if(LTPLPs != null)
		{
		Iterator<LTPLPs> iterator = LTPLPs.iterator();
		while(iterator.hasNext())
		{
			LTPs.add(iterator.next().uuid);
		}
		}
		return LTPs;
	}
	
	public static String getProtocalName(String nodeId,String uuid)
	{
		ArrayList<LTPLPs> LTPLPs = DataBase.LTPLPs.get(nodeId);
		Iterator<LTPLPs> iterator = LTPLPs.iterator();
		while(iterator.hasNext())
		{
			LTPLPs LTP = iterator.next();
			if(LTP.uuid.equals(uuid))
			{
				return LTP.protocolName;
			}
		}
		return null;
	}
	
	public static String getLpId(String nodeId,String uuid)
	{
		ArrayList<LTPLPs> LTPLPs = DataBase.LTPLPs.get(nodeId);
		Iterator<LTPLPs> iterator = LTPLPs.iterator();
		while(iterator.hasNext())
		{
			LTPLPs LTP = iterator.next();
			if(LTP.uuid.equals(uuid))
			{
				return LTP.lpId;
			}
		}
		return null;
	}
}
