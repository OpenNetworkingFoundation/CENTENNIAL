package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;

import rmon.LoadDatabase;
import rmon.common.Configuration;
import rmon.logger.Log;

public class MyComData {
	
	String nodeId;
	String ConnectorName;
	String linkName;
	public static String file = Configuration.InputPath + File.separator + "MyComData.txt";

	public MyComData(String nodeId, String ConnectorName,String linkName ) {
		this.nodeId = nodeId;
		this.ConnectorName = ConnectorName;
		this.linkName = linkName;
	}

	public static void loadFromInput(Set<String> nodes) {
		String nodeId = "notdefined";
		String myCommConnectorName = "not-defined";
		String myCommLinkName = "not-defined";
		try {
			File myCommFile = new File(file);
			if (myCommFile.exists()) {

				Scanner scan = new Scanner(myCommFile);
				while (scan.hasNextLine()) {
					String line = scan.nextLine();
					String[] details = line.split(";");
					if(details.length >= 3)
						{
						    nodeId = details[0];						    
							myCommConnectorName = details[1];
							myCommLinkName = details[2];
							DataBase.setMyCommData(nodeId + ":::" + myCommConnectorName, myCommLinkName);
							nodes.add(nodeId);
						}	
				}
				scan.close();
			}
		} catch (Exception ex) {
			Log.Error("exception in retrieving vendorNames from file" + nodeId);
			Log.Error(ex);
		}
	}

}
