package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.LoadDatabase;
import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.logger.Log;

public class ServerClientLTPs {
	
	public String nodeId;
	public String uuid;
	public JSONArray serverLTP;
	public JSONArray clientLTP;
	public static String file = Configuration.DBPath + File.separator + "ClientServerLTPs";	
	
	public ServerClientLTPs(String nodeId,String uuid,JSONArray serverLTP,JSONArray clientLTP) {
		this.nodeId = nodeId;
        this.uuid = uuid;        
        this.serverLTP = serverLTP;
        this.clientLTP = clientLTP;
    }

	@Override
	public String toString() {
		return "ServerClientLTPs [uuid=" + uuid + ", serverLTP=" + serverLTP + ", clientLTP=" + clientLTP + "]";
	}
	
	/*
	 * In the file , details will be in the format nodeId:::uuid:::clientLTP:::ServerLTP
	 */
	public static void loadFromDB(String nodeId,LoadDatabase process)
	{
		try {
			ArrayList<ServerClientLTPs> LTPArray = new ArrayList<ServerClientLTPs>();
			File serverClientLtpFile = new File(file);
			if (serverClientLtpFile.exists()) {				
				Scanner scan = new Scanner(serverClientLtpFile);
				while (scan.hasNextLine()) {
					String content = scan.nextLine();
					String[] details = content.split(":::");
					String nodeName = details[0];

					if (nodeName.equals(nodeId)) {
						String uuid = details[1];
						String serverLTP = details[2];
						String clientLTP = details[3];
						JSONArray serverLTPArray = new JSONArray(serverLTP);
						JSONArray clientLTPArray = new JSONArray(clientLTP);
						ServerClientLTPs LTP = new ServerClientLTPs(nodeId,uuid, serverLTPArray, clientLTPArray);
						LTPArray.add(LTP);
					}
				}
				scan.close();				
			}
			if (LTPArray.size() != 0) {
				DataBase.setServerClientLTPs(nodeId, LTPArray);
				LTPLPs.loadFromDB(nodeId);
			}
			else
			{
				loadFromController(nodeId,process);
			}			
			MaptheLayers(nodeId);
		} catch (Exception ex) {
			Log.Error("exception in retrieving server-ltp details from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
	
	public static void loadFromController(String nodeId,LoadDatabase process)
	{
		JSONArray response = RestOperations.getLogicalTerminationPoint(nodeId);
		if(response!=null)
		{
		loadFromResponse(nodeId,response,process);
		LTPLPs.loadFromResponse(nodeId, response);
		}
	}
	
	public static void loadFromResponse(String nodeId,JSONArray response,LoadDatabase process)
	{
		try {
		ArrayList<ServerClientLTPs> LArray = new ArrayList<ServerClientLTPs>();		
		for (int i = 0; i < response.length(); i++) {
			WriteToFile serverClientLTPWriter = new WriteToFile(file);
			String uuid = "";
			JSONArray serverLTP = new JSONArray();
			JSONArray clientLTP = new JSONArray();
			JSONObject json = response.getJSONObject(i);
			if (!json.has("server-ltp") && !json.has("client-ltp")) {
				uuid = json.getString("uuid");

			} else if (!json.has("server-ltp")) {
				uuid = json.getString("uuid");
				clientLTP = json.getJSONArray("client-ltp");

			} else if (!json.has("client-ltp")) {
				uuid = json.getString("uuid");
				serverLTP = json.getJSONArray("server-ltp");

			} else {
				uuid = json.getString("uuid");
				serverLTP = json.getJSONArray("server-ltp");
				clientLTP = json.getJSONArray("client-ltp");

			}
			ServerClientLTPs LTP = new ServerClientLTPs(nodeId,uuid, serverLTP, clientLTP);
			LArray.add(LTP);
			serverClientLTPWriter.write(nodeId + ":::" + uuid + ":::" + serverLTP.toString() + ":::" + clientLTP.toString());
		}
		DataBase.setServerClientLTPs(nodeId, LArray);
		}catch(Exception ex)
		{
			Log.Error("exception in processing the server-ltp details from controller" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
	
	public static void MaptheLayers(String nodeId)
	{
		try {
		ArrayList<LTPLPs> LogicalProtocolMap = DataBase.LTPLPs.get(nodeId);
		Map<String,String> MapWANConnectedLayer = new HashMap<String,String>();
		Map<String,String> MapLANConnectedLayer = new HashMap<String,String>();
		if(LogicalProtocolMap == null)
		{
			Log.Error("No server client details loaded for the node : "+nodeId);
			return;
		}
		Iterator<LTPLPs> iter = LogicalProtocolMap.iterator();
		while(iter.hasNext())
		{
			try {
			//Note : connection String in the format LTP --> conn1 --> conn2 : nextconn1 --> nextconn2 
			LTPLPs LTP = iter.next();
			if(LTP.protocolName.contains("LAYER_PROTOCOL_NAME_TYPE_AIR_LAYER"))
				{
				String connection = getLayerConnection(nodeId,LTP.uuid);
				MapWANConnectedLayer.put(LTP.uuid, connection);
				}else if(LTP.protocolName.contains("LAYER_PROTOCOL_NAME_TYPE_WIRE_LAYER"))
				{
				String connection = getLayerConnection(nodeId,LTP.uuid);
				MapLANConnectedLayer.put(LTP.uuid, connection);
				}
			}catch(Exception ex)
			{
				Log.Error("Issue in mapping the interlinked layer for the node : "+nodeId + " for one LTP ");
				Log.Error(ex);
			}
		}
		DataBase.setMapWANConnectedLayers(nodeId, MapWANConnectedLayer);
		DataBase.setMapLANConnectedLayers(nodeId, MapLANConnectedLayer);
		}
		catch(Exception ex)
		{
			Log.Error("Issue in mapping the interlinked layer for the node : "+nodeId);
			Log.Error(ex);
		}
	}
	
	
	public static String getLayerConnection(String nodeId,String uuid) {
		
	    String connection = "";
	    try
		{
	    ArrayList<ServerClientLTPs> layers = DataBase.ServerClientLTPs.get(nodeId);
	    Iterator<ServerClientLTPs> LTPIter = layers.iterator();
	    while(LTPIter.hasNext())
	    {
	    	try {
	    	ServerClientLTPs ltp = LTPIter.next();	    	
	    	if(ltp.uuid.equals(uuid))
	    	{
	    		JSONArray clientLTP = ltp.clientLTP;
	    		if(clientLTP.isEmpty())
	    		{
	    			return uuid + ":";
	    		}
	    		for(int i=0;i<clientLTP.length();i++)
	    		{
	    			connection = connection + uuid + "-->>" + getLayerConnection(nodeId,clientLTP.getString(i));
	    		}
	    	}
	    	}catch(Exception ex)
	    	{
	    		Log.Error("Issue in processing the getLayerConnection inner while loop for the node : "+nodeId + " and the uuid :" + uuid);
				Log.Error(ex);
	    	}
	    }
		}catch(Exception ex)
	    {
			Log.Error("Issue in processing the getLayerConnection for the node : "+nodeId + " and the uuid :" + uuid);
			Log.Error(ex);
	    }
	    
	    return connection;	    
	}

}
