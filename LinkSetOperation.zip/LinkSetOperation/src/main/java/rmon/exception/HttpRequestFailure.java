package rmon.exception;

import org.apache.http.HttpResponse;

public class HttpRequestFailure extends Exception {

	HttpResponse response; 
	String url;
	
	public HttpRequestFailure(HttpResponse response,String url) {
		this.response = response;
		this.url = url;
	}

	public String toString() {
		return ("HttpRequestFailure : " + response.getStatusLine().getStatusCode() + ":" +url);
	}

}
