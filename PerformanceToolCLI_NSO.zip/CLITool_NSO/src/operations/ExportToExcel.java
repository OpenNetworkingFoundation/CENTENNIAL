package operations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import resources.TaskResult;

public class ExportToExcel {

	String taskName;

	public ExportToExcel(String taskname) {
		super();
		taskName = taskname;
		exportTasksToExcel();
	}

	public void exportTasksToExcel() {

		System.out.println("exporting to excel");
		FileOutputStream excelFos = null;
		SXSSFWorkbook excelJTableExport = null;
		try {

			/*
			 * JFileChooser excelFileChooser = new
			 * JFileChooser("C:\\Users\\Authentic\\Desktop");
			 * excelFileChooser.setDialogTitle("Save As .."); FileNameExtensionFilter fnef =
			 * new FileNameExtensionFilter("Files", "xlsx");
			 * excelFileChooser.setFileFilter(fnef); int chooser =
			 * excelFileChooser.showSaveDialog(null); if (chooser ==
			 * JFileChooser.APPROVE_OPTION) {
			 */
				excelJTableExport = new SXSSFWorkbook();
				Sheet excelSheet = excelJTableExport.createSheet(taskName);
				// creating heading field
				Row headerRow = excelSheet.createRow(0);
				String headingRow = "Iteration,No.,Details,TestSuite,Content,URL Details, Start Time, End Time, Status, Response Time, Response Got";
				String[] headings = headingRow.split(",");
				for (int heading = 0; heading < headings.length; heading++) {
					headerRow.createCell(heading).setCellValue(headings[heading]);
				}

				ArrayList<TaskResult> resultList = readTheEntireFolder();

				int rowCount = 0;
				// populating rows of the excel sheet
				for (TaskResult result : resultList) {

					Row row = excelSheet.createRow(++rowCount);
					int columnCount = 0;
					row.createCell(columnCount++).setCellValue(result.getIteration());
					row.createCell(columnCount++).setCellValue(result.getNo());
					row.createCell(columnCount++).setCellValue(result.getDetails());
					row.createCell(columnCount++).setCellValue(result.getTestSuite());
					row.createCell(columnCount++).setCellValue(result.getContent());
					row.createCell(columnCount++).setCellValue(result.getUrlDetails());
					row.createCell(columnCount++).setCellValue(result.getStartTime());
					row.createCell(columnCount++).setCellValue(result.getEndTime());
					row.createCell(columnCount++).setCellValue(result.getStatus());
					row.createCell(columnCount++).setCellValue(result.getResponseTime());
					row.createCell(columnCount++).setCellValue(result.getResposeGot());

				}
			
				String fileOutput = Main.outputFilesPath + File.separator + taskName + File.separator + taskName +".xlsx";
				excelFos = new FileOutputStream(fileOutput);
				excelJTableExport.write(excelFos);
	
		} catch (Exception ex) {
			System.out.println("Exception in creating excel:" + ex.getMessage());
		} finally {
			try {
				
				if(excelFos!=null) {
					excelFos.close();
				}
				/*
				 * if (excelFos != null) { excelFos.close(); } if (excelJTableExport != null) {
				 * excelJTableExport.close(); }
				 */
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(null, ex);
			}
		}

	}

	public ArrayList<TaskResult> readTheEntireFolder() throws IOException {
		ArrayList<TaskResult> result = new ArrayList<TaskResult>();
		//String path = Main.getUsersHomeDir() + File.separator + "ControllerTasks" + File.separator + taskName;
		
		String path = Main.outputFilesPath + File.separator + taskName;
		System.out.println(path);
		File folderPath = new File(path);
		if (folderPath.isDirectory()) {
			File[] listOfFiles = folderPath.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {

				if (listOfFiles[i].isFile()) {
					String fileName = path + File.separator + listOfFiles[i].getName();
					BufferedReader br = new BufferedReader(
							new InputStreamReader(new FileInputStream(new File(fileName))));
					int no = 1;
					String line = "";
					while ((line = br.readLine()) != null) {

						if (line.contains("----------")) {
							String data[] = line.split("----------");
							result.add(new TaskResult(Integer.toString(i + 1), Integer.toString(no), data[1], data[2],
									data[3], data[4], data[5], data[6], data[7], data[8], data[9]));
							no += 1;
						}
					}
				}
			}
		} else {
			System.out.println("This is not a valid directory");
		}
		return result;
	}
}
