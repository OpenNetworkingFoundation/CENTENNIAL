package operations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import framework.ControllerConfig;
import framework.SimpleParallelRestCallThread;
import framework.SimpleRestCallThread;
import resources.CurrentTestSuite;
import resources.Repository;
import resources.TaskDetails;
import scheduler.CustomScheduler;

public class Main {
	public static String controllerIPAddress;
	public static String targetPathFolder;
	public static String pathFolder;
	public static String basePath;
	public static String outputFilesPath;
	
	
	public static void main(String[] args) throws IOException {

		String no;
		String type;
		String testSuite;
		String details;
		String context;
		String lpname;
		String ltp_lp_id;
		String uuid;
		String nodename;
		
		
		//login to controller
		System.out.println("Login to controller");
		//String rootPath = getUsersHomeDir() + File.separator + "ControllerTasksInfo";
		String credentialsfile = "credentials.txt";
		File credentialsFile = new File(credentialsfile);
		//File credentialsFile = new File(rootPath + File.separator + credentialsfile);
		Map<String,String> credentials = new HashMap<String, String>();
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(credentialsFile)));
			String credential="";
			while((credential = reader.readLine())!=null) {
				
				if(credential.contains(":")) {
					credentials.put(credential.split(":")[0], credential.split(":")[1]);
				}
				
			}
			new ControllerConfig(credentials.get("ControllerIp"), credentials.get("username"),credentials.get("password"), Integer.parseInt(credentials.get("port")));
			controllerIPAddress = credentials.get("ControllerIp");
			ExecutorService executorForLogin = Executors.newSingleThreadExecutor();
			executorForLogin.execute(new LoginToController().task);
			executorForLogin.shutdown();
			executorForLogin.awaitTermination(3, TimeUnit.MINUTES);
		}
		catch(Exception e) {
			System.out.println("login not successful" + e.getMessage());
		}
		
		
		try {
		//reading the file and retrieving the details
		String filename = args[0].toString();
		File fileName = new File(filename);
		if(fileName.exists()) {
			targetPathFolder = getUsersHomeDir() + File.separator + "ControllerData";
			if(!new File(targetPathFolder).exists()) {
				new File(targetPathFolder).mkdir();
			}
			 pathFolder = targetPathFolder + File.separator + "Controller_" + controllerIPAddress.replace(".", "");
			if(!new File(pathFolder).exists()) {
				new File(pathFolder).mkdir();
			}
			 basePath = pathFolder + File.separator + "PerformanceToolCLI_NSO";
			if(!new File(basePath).exists()) {
				new File(basePath).mkdir();
			}
			 outputFilesPath = basePath + File.separator + "TaskOutputFiles";
			if(!new File(outputFilesPath).exists()) {
				new File(outputFilesPath).mkdir();
			}
			
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			String taskDetails = br.readLine();
			String[] taskDetail = taskDetails.split("::");
			String taskName = taskDetail[0];
			String targetPath = outputFilesPath + File.separator + taskName;
			if(!new File(targetPath).exists()) {
				String descriptionString =taskDetail[1];
				String executionType = taskDetail[2];
				String selectedFrequency = taskDetail[3];
				String iteration = taskDetail[4];
				String suiteDetails ="";
				Map<String,String> LogicalProtocolMap = new HashMap<String, String>();
				Map<String,String> LTP_LPMap = new HashMap<String, String>();
				while((suiteDetails = br.readLine()) != null) {
					String[] suiteDetail = suiteDetails.split("::");
					no = suiteDetail[0];
					type = suiteDetail[1];
					testSuite = suiteDetail[2];
					details = suiteDetail[3];
					context = suiteDetail[4];
					lpname = suiteDetail[5];
					ltp_lp_id = suiteDetail[6];
					CurrentTestSuite.CurrentList.add(new CurrentTestSuite(no, type, testSuite, details, context));
					if(details.contains(":")) {
						uuid = details.split(":")[1];
						nodename = details.split(":")[0];
						LogicalProtocolMap.put(uuid, lpname);
						LTP_LPMap.put(uuid, ltp_lp_id);
					}
					else {
						uuid = "";
						nodename = "";
					}
					Repository.MapLogicalProtocolMap.put(nodename, LogicalProtocolMap);
					Repository.MapLTP_LPMap.put(nodename, LTP_LPMap);
				}
				
				ArrayList<CurrentTestSuite> suiteList = new ArrayList<CurrentTestSuite>();
		    	Iterator<CurrentTestSuite> suiteIterator = CurrentTestSuite.CurrentList.iterator();
		    	while(suiteIterator.hasNext())
		    	{
		    		suiteList.add(suiteIterator.next());
		    	}
		    	
		    	if(!selectedFrequency.equals("0-0-0"))
		    	{
		    		TaskDetails newTask = new TaskDetails(taskName,descriptionString,suiteList,executionType,selectedFrequency,iteration);
		    		TaskDetails.taskRepo.put(newTask.taskName,newTask);
		    		CustomScheduler newSchedule = new CustomScheduler(taskName,executionType,iteration);
				     try { 
						newSchedule.run1();
					 }
					 catch(Exception ex) {
						JOptionPane.showMessageDialog(null,"something went wrong.. Please restart the application"); 
					 }
						 
				}
		    	else
				{
		    		TaskDetails newTask = new TaskDetails(taskName,descriptionString,suiteList,executionType,selectedFrequency,iteration);
		    		TaskDetails.taskRepo.put(newTask.taskName,newTask);
					if(executionType.equalsIgnoreCase("Serial"))
					{	
						
						new Thread(new SimpleRestCallThread(taskName)).start();
					}
					else
					{		
						new Thread(new SimpleParallelRestCallThread(taskName)).start();
					}
				}
					
			}
			else {
				System.out.println("---------------------------------------------------");
				System.out.println("the task name already exists" + taskName);
				
				File taskFolder = new File(outputFilesPath);
				if(taskFolder.isDirectory()) {
					File[] listOfFiles = taskFolder.listFiles();
					for( File file: listOfFiles) {
						if(file.isDirectory()) {
							System.out.println(file.getName());
						}
					}
					System.out.println("---------------------------------------------------");
					System.out.println("These are the task files available.. please select a new task name");
				}
			}
		}
		else {
			System.out.println("File doesnot exist");
			
		}
		}
		catch(Exception e) {
			System.out.println("exception in main");
			e.printStackTrace();
		}
	    
		
	}
	public static String getUsersHomeDir() {
	    String users_home = System.getProperty("user.home");
	    return users_home.replace("\\", "/"); // to support all platforms.
	}
}
