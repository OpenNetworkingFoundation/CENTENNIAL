package resources;

import framework.ControllerConfig;

public class GetURL {

	public static String getURL(String request, String type, String nodeName, String content) {
		if (type.equals("Controller")) {
			if (request.equals("Get node mount status")) {
				String url = RestConfURL.CONTROLLER_URL.getUrl()
						+ RestConfURL.DEVICE_STATUS.getUrl().replace("<config>", content);
				if (content.equals("none")) {
					url = url.replace("content=none&", "");
				}
				return url;
			} else if (request.equals("Get Node details")) {

				String url = RestConfURL.CONTROLLER_URL.getUrl()
						+ RestConfURL.FILTER_NODEID.getUrl().replace("<config>", content);
				if (content.equals("none")) {
					url = url.replace("content=none&", "");
				}
				return url;
			}
		} else if (type.equals("Node")) {
			if (request.equals("Get Device Capabilities")) {
				String url = RestConfURL.CONTROLLER_URL.getUrl() + "/node=" + nodeName;
				if (!content.equals("none")) {
					url = url + "?content=" + content;
				}
				return url;
			} else if (request.equals("Get LTP Details")) {
				String url = "http://"+ControllerConfig.IP+":"+ControllerConfig.port+"/restconf/data/tailf-ncs:devices/device="+nodeName +"/"+content+"/core-model-1-4:control-construct?fields=logical-termination-point";

				/*String url = RestConfURL.CONTROLLER_URL.getUrl()
						+ RestConfURL.NODE_URL.getUrl().replace("<NODE_ID_OR_NAME>", nodeName)
						+ RestConfURL.FILTER_LPID.getUrl().replace("<config>", content);
				if (content.equals("none")) {
					url = url.replace("content=none&", "");
				}*/
				return url;
			} else if (request.equals("Get Device control-construct")) {
				String url = "http://"+ControllerConfig.IP+":"+ControllerConfig.port+"/restconf/data/tailf-ncs:devices/device="+nodeName +"/"+content+"/core-model-1-4:control-construct";

				
				/*String url = RestConfURL.CONTROLLER_URL.getUrl()
						+ RestConfURL.NODE_URL.getUrl().replace("<NODE_ID_OR_NAME>", nodeName);
				if (!content.equals("none")) {
					url = url + "?content=" + content;
				}*/
				return url;
			}
			// http://10.118.125.76:8181/rests/data/network-topology:network-topology/topology=topology-netconf/node=ericsson_trafficnode_06251/yang-ext:mount/core-model-1-4:control-construct
		} else {
			String nodeID = nodeName.split(":")[0];
			String LTPID = nodeName.split(":")[1];
			String LPID = Repository.MapLTP_LPMap.get(nodeID).get(LTPID);
			String url = RestConfURL.CONTROLLER_URL.getUrl()
					+ RestConfURL.NODE_URL.getUrl().replace("<NODE_ID_OR_NAME>", nodeID)
					+ RestConfURL.LP_URL.getUrl().replace("<LTP_ID>", LTPID).replace("<LP_ID>", LPID);
			if (request.contains("AirInterface")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.AIR_INTERFACE_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.AIR_INTERFACE_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.AIR_INTERFACE_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}
			} else if (request.contains("EthernetInterface")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.ETHERNET_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.ETHERNET_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.ETHERNET_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}

			} else if (request.contains("HybridMicrowaveStructure")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.HYBRID_MICROWAVE_STRUCTURE_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.HYBRID_MICROWAVE_STRUCTURE_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.HYBRID_MICROWAVE_STRUCTURE_CONFIGURATION.getUrl() + "/"
							+ request.split(" ")[3];
				}

			} else if (request.contains("MacInterface")) {

				if (request.contains("Capability")) {
					url = url + RestConfURL.MAC_INTERFACE_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.MAC_INTERFACE_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.MAC_INTERFACE_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}
			} else if (request.contains("PureEthernet")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.PURE_ETHERNET_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.PURE_ETHERNET_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.PURE_ETHERNET_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}

			} else if (request.contains("TDMContainer")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.TDM_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.TDM_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.TDM_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}

			} else if (request.contains("WireInterface")) {
				if (request.contains("Capability")) {
					url = url + RestConfURL.WIRE_INTERFACE_CAPABILITY.getUrl();
				} else if (request.contains("Configuration")) {
					url = url + RestConfURL.WIRE_INTERFACE_CONFIGURATION.getUrl();
				} else {
					url = url + RestConfURL.WIRE_INTERFACE_CONFIGURATION.getUrl() + "/" + request.split(" ")[3];
				}

			}

			if (!content.equals("none")) {
				url = url + "?content=" + content;
			}

			return url;
		}

		return null;
	}

}
