package resources;

public class TaskResult {
	
	String iteration;
	String no ;
	String details;
	String testSuite;
	String content;
	String urlDetails;
	String startTime;
	String endTime;
	String status;
	String responseTime;
	String resposeGot;
	
	public TaskResult(String iteration, String no, String details, String testSuite, String content, String urlDetails,
			String startTime, String endTime, String status, String responseTime, String resposeGot) {
		super();
		this.iteration = iteration;
		this.no = no;
		this.details = details;
		this.testSuite = testSuite;
		this.content = content;
		this.urlDetails = urlDetails;
		this.startTime = startTime;
		this.endTime = endTime;
		this.status = status;
		this.responseTime = responseTime;
		this.resposeGot = resposeGot;
	}

	public String getIteration() {
		return iteration;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getTestSuite() {
		return testSuite;
	}

	public void setTestSuite(String testSuite) {
		this.testSuite = testSuite;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrlDetails() {
		return urlDetails;
	}

	public void setUrlDetails(String urlDetails) {
		this.urlDetails = urlDetails;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public String getResposeGot() {
		return resposeGot;
	}

	public void setResposeGot(String resposeGot) {
		this.resposeGot = resposeGot;
	}

	public void setIteration(String iteration) {
		this.iteration = iteration;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}
	
	
	
	

}
