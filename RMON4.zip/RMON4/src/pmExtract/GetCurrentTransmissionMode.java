package pmExtract;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public class GetCurrentTransmissionMode {
	
	public static String getCurrentTransmissionMode(String Nodeid,String uuid,String lpid) throws Exception {
		String CurrentTransmissionMode = new String();
		String URL = "http://"+LoginToController.Controller_ip+":8181/rests/data/network-topology:network-topology/topology=topology-netconf/node=" 
				+ Nodeid + "/yang-ext:mount/core-model-1-4:control-construct/logical-termination-point=" 
				+ uuid +"/layer-protocol=" 
				+ lpid + "/air-interface-2-0:air-interface-pac/air-interface-current-performance";
    	HttpHost targetHost = new HttpHost(LoginToController.Controller_ip, 8181, "http");
    	CredentialsProvider credsProvider = new BasicCredentialsProvider();
    	credsProvider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(LoginToController.Controller_username, LoginToController.Controller_password));
    	
    	//defining basic authentication
    	AuthCache authCache = new BasicAuthCache();
    	authCache.put(targetHost, new BasicScheme());
    	 
    	// Add AuthCache to the execution context
    	HttpClientContext context = HttpClientContext.create();
    	context.setCredentialsProvider(credsProvider);
    	context.setAuthCache(authCache);
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	//connecting to the server and getting the first request
        try {
            HttpGet httpGet = new HttpGet(URL);
            HttpResponse response = client.execute(httpGet,context);
            try {
                //System.out.println(response.getStatusLine());
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                StringBuilder builder = new StringBuilder();
                for (String line = null; (line = reader.readLine()) != null;) {
                    builder.append(line).append("\n");
                }
                JSONObject finalResult = new JSONObject(builder.toString());
                //getting core-model
                JSONObject coreModel  = (JSONObject)finalResult.get("air-interface-2-0:air-interface-current-performance");
                //getting current performance data
                JSONArray capability  = coreModel.getJSONArray("current-performance-data-list");
                //getting the 15-min bin
                JSONObject Bincapability=  capability.getJSONObject(0);
                //get the time-period data 
                int timePeriod=  Bincapability.getJSONObject("performance-data").getInt("time-period");
                //get the TimeXstatesList
                JSONArray timeXStatesList = Bincapability.getJSONObject("performance-data").getJSONArray("time-xstates-list");
                //select current transmission mode by comparing the time-period data
                for(int i=0;i<timeXStatesList.length();i++)
                {
                	JSONObject timeXState = timeXStatesList.getJSONObject(i);
                	if(timeXState.getInt("time") == timePeriod)
                	{
                		CurrentTransmissionMode = timeXState.getString("transmission-mode");
                	}
                }
                
                
            } finally {
                
            }
            
        } finally {
            
        }
        return CurrentTransmissionMode;
    }

}
