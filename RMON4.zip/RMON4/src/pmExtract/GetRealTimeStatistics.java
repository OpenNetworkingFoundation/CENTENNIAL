package pmExtract;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public class GetRealTimeStatistics {
	
	public static String getRealTimeStatistics(String Nodeid,String uuid,String lpid) throws Exception {
		String report = new String();
		String URL = "http://"+LoginToController.Controller_ip+":8181/rests/data/network-topology:network-topology/topology=topology-netconf/node=" 
				+ Nodeid + "/yang-ext:mount/core-model-1-4:control-construct/logical-termination-point=" 
				+ uuid +"/layer-protocol=" 
				+ lpid + "/ethernet-container-2-0:ethernet-container-pac/ethernet-container-status";
    	HttpHost targetHost = new HttpHost(LoginToController.Controller_ip, 8181, "http");
    	CredentialsProvider credsProvider = new BasicCredentialsProvider();
    	credsProvider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(LoginToController.Controller_username, LoginToController.Controller_password));
    	
    	//defining basic authentication
    	AuthCache authCache = new BasicAuthCache();
    	authCache.put(targetHost, new BasicScheme());
    	 
    	// Add AuthCache to the execution context
    	HttpClientContext context = HttpClientContext.create();
    	context.setCredentialsProvider(credsProvider);
    	context.setAuthCache(authCache);
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	//connecting to the server and getting the first request
        try {
            HttpGet httpGet = new HttpGet(URL);
            Main.log("RealTimeStatistics : going to fetch the statistics for the details " + Nodeid + " LTP -" + uuid + "is "+ URL );
            HttpResponse response = client.execute(httpGet,context);
            Main.log("GetRealTimeStatistics : response for the url " + URL + "is " + response.getStatusLine().getStatusCode());
            try {
                //System.out.println(response.getStatusLine());
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                StringBuilder builder = new StringBuilder();
                for (String line = null; (line = reader.readLine()) != null;) {
                    builder.append(line).append("\n");
                }
                Main.log("GetRealTimeStatistics : result for statistics are being processed for the request with Nodeid " + Nodeid + " uuid " + uuid + " lpid " + lpid + " ethernet-container-status ");
                JSONObject finalResult = new JSONObject(builder.toString());
                //getting core-model
                JSONObject coreModel  = (JSONObject)finalResult.get("ethernet-container-2-0:ethernet-container-status");
                //getting ethernet-container-status
                Boolean statisticsIsUp = coreModel.getBoolean("statistics-is-up");
                String interfaceStatus = coreModel.getString("interface-status");
                if(interfaceStatus.contains("DOWN"))
                {
                	interfaceStatus = "Down";
                }
                else
                {
                	interfaceStatus = "Up";
                }
                String totalBytesOutput =coreModel.getString("total-bytes-output");
                String totalBytesInput =coreModel.getString("total-bytes-input");
                //report = generateResult( uuid, statisticsIsUp, interfaceStatus, totalBytesOutput, totalBytesInput);
                //report = "statistics-Is-Up\t"+statisticsIsUp+"\tinterface-Status\t"+ interfaceStatus + "\ttotal-Bytes-Inputt\t" + totalBytesOutput + "\ttotal-Bytes-Output\t"
                		//+ totalBytesOutput;
                report = statisticsIsUp+"\t"+ interfaceStatus + "\t" + totalBytesInput + "\t"
                		+ totalBytesOutput;
                Main.log("GetRealTimeStatistics : processed all the output for Nodeid " + Nodeid + " uuid " + uuid + " lpid " + lpid + " and the report is " + report );
                
            } finally {
                
            }
            
        } finally {
            
        }
        return report;
    }
	
	public static String generateResult(String uuid,Boolean statisticsIsUp,String interfaceStatus,String totalBytesOutput,String totalBytesInput)
	{
		String report = new String();
		//checking Preconditions
		if(statisticsIsUp == true && interfaceStatus.contains("INTERFACE_STATUS_TYPE_UP"))
		{
			report = "RealTime Statistic for the connected Ethernet Interface : " + uuid
					+"\n************************************************************************************\n"
					+"\n Preconditions satisfied : "
					+"\n Is statistic up : " + statisticsIsUp
					+"\n Is Interface Status up : " + interfaceStatus 
					+"\n Total Bytes Input : " + totalBytesInput
					+"\n Total Bytes Output : " + totalBytesOutput
					+"\n\n\n";
		}else
		{
			report = "RealTime Statistic for the connected Ethernet Interface : " + uuid
					+"\n************************************************************************************\n"
					+"\n Preconditions are not satisfied : "
					+"\n Is statistic up : " + statisticsIsUp
					+"\n Is Interface Status up : " + interfaceStatus 
					+"\n\n\n";
		}
		return report;
	}

}
