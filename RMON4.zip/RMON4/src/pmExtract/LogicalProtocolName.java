package pmExtract;


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;


public class LogicalProtocolName {

	public static Map<String,Map<String,String>> LogicalProtocolMap = new HashMap<String,Map<String, String>>();
	public static Map<String,Map<String,String>> LTP_LPMap = new HashMap<String, Map<String,String>>();
	public int iteration = 1;
	public static void getLogicalProtocolName(String Nodeid) throws Exception {
		
    	HttpHost targetHost = new HttpHost(LoginToController.Controller_ip, 8181, "http");
    	CredentialsProvider credsProvider = new BasicCredentialsProvider();
    	credsProvider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(LoginToController.Controller_username, LoginToController.Controller_password));
    	
    	//defining basic authentication
    	AuthCache authCache = new BasicAuthCache();
    	authCache.put(targetHost, new BasicScheme());
    	 
    	// Add AuthCache to the execution context
    	HttpClientContext context = HttpClientContext.create();
    	context.setCredentialsProvider(credsProvider);
    	context.setAuthCache(authCache);
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	
    	//connecting to the server and getting the first request
        try {
        	String URL = new String("http://"+LoginToController.Controller_ip+":8181/rests/data/network-topology:network-topology/topology=topology-netconf/node="+Nodeid+"/"
        			+ "yang-ext:mount/core-model-1-4:control-construct?content="+LoginToController.Node_Config+"&fields=logical-termination-point(uuid;layer-protocol(layer-protocol-name;local-id))");
            HttpGet httpGet = new HttpGet(URL);
            HttpResponse response = client.execute(httpGet,context);
            try {
                //System.out.println(response.getStatusLine());
            	Main.log("LogicalProtocolName : trying to get the lp and LTP details for the node :" + Nodeid + " using the URL "+URL);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                StringBuilder builder = new StringBuilder();
                for (String line = null; (line = reader.readLine()) != null;) {
                    builder.append(line).append("\n");
                }
                JSONObject finalResult = new JSONObject(builder.toString());
                //getting core-model
                JSONObject coreModel  = (JSONObject)finalResult.get("core-model-1-4:control-construct");
                //getting LTPs
                JSONArray LTPDetails  = coreModel.getJSONArray("logical-termination-point");
                MapProtocolName(Nodeid,LTPDetails);
                MapConnectedLayers.MaptheLayers(Nodeid,LogicalProtocolMap.get(Nodeid));
                //LogicalTerminationPoints.mainWindow();
                //System.out.println(LTPArray);
                //calculate the airinterface capacities
                
                for(int i=LoginToController.iteration,inumber=1;i>0;i--,inumber++)
                {
                if(!MapConnectedLayers.MapWANConnectedLayers.isEmpty())
                {
                	Iterator<String> iter = MapConnectedLayers.MapWANConnectedLayers.get(Nodeid).keySet().iterator();
            		while(iter.hasNext())
            		{
            			String uuid = iter.next();
            			int inum = inumber;
            			Thread thread = new Thread() {public void run() {
            				Main.log("LogicalProtocolName : started processing for AirInterfaceCapacity for " + Nodeid + uuid);
            				String info = AirInterfaceCapacity.AirInterfaceCapacityDetails(Nodeid,uuid); 
                			System.out.println("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t"+"AirInterfaceCapacity"+"\t"+new Date()+"\t"+info);	
                			WriteToFile airInterfacewriter = new WriteToFile(Main.airInterface);               
                			airInterfacewriter.write("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t" + "AirInterface\t" +new Date()+"\t"+info+"\n");	
                			airInterfacewriter.close();
            			}};
            			thread.start();
            			Thread thread1 = new Thread() {public void run() {
            				Main.log("LogicalProtocolName : started processing for RealTimeStatistics for " + Nodeid + uuid);
            				String info = RealTimeStatistics.getRealTimeStatistics(Nodeid,uuid);     
                			System.out.println("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t"+"Real-Time-Statistics"+"\t"+new Date()+"\t"+info);	
                			WriteToFile realTimeWriter = new WriteToFile(Main.realTime);                			
                			realTimeWriter.write("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t" + "AirInterface\t" +new Date()+"\t"+info+"\n");
                			realTimeWriter.close();
            			}};
            			thread1.start();
            			
            		}
                }
                
                if(!MapConnectedLayers.MapLANConnectedLayers.isEmpty())
                {
                	Iterator<String> iter = MapConnectedLayers.MapLANConnectedLayers.get(Nodeid).keySet().iterator();
            		while(iter.hasNext())
            		{
            			String uuid = iter.next();
            			int inum = inumber;
            			Thread thread1 = new Thread() {public void run() {
            				Main.log("LogicalProtocolName : started processing for RealTimeStatistics for " + Nodeid + uuid);
            				String info = RealTimeStatistics.getRealTimeStatistics(Nodeid,uuid);     
                			System.out.println("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t"+"Real-Time-Statistics"+"\t"+new Date()+"\t"+info);
                			WriteToFile realTimeWriter = new WriteToFile(Main.realTime);         
                			realTimeWriter.write("Iteration-"+ inum +"\t" + Nodeid+"\t"+uuid+"\t"+ "wireInterface\t"+new Date()+"\t"+info+"\n");
                			realTimeWriter.close();
            			}};
            			thread1.start();       			
            			
            		}
                }
                Thread.sleep(LoginToController.frequency);
                }
                
                
            } 
            catch(Exception ex)
            {
            	
            }
            finally {
                
            }
            
        } catch(Exception ex)
        {
        	
        }finally {
        	
        }
    }
    
    public static void MapProtocolName(String Nodeid,JSONArray LTPDetails)
    {
    	Map<String,String> LogicalProtocolMa = new HashMap<String,String>();
    	Map<String,String> LTP_LPMa = new HashMap<String,String>();
    	for(int i=0;i<LTPDetails.length();i++)
    	{
    		JSONObject json = LTPDetails.getJSONObject(i);
    		String uuid = json.getString("uuid");
    		JSONArray Protocol = json.getJSONArray("layer-protocol");
    		if(Protocol.getJSONObject(0).has("layer-protocol-name"))
    		{
    			String ProtocolName = Protocol.getJSONObject(0).getString("layer-protocol-name");    			
        		LogicalProtocolMa.put(uuid, ProtocolName);	
    		}else
    		{
    			LogicalProtocolMa.put(uuid, new String());
    		}
    		
    		if(Protocol.getJSONObject(0).has("local-id"))
    		{
    			String ProtocolName = Protocol.getJSONObject(0).getString("local-id");    			
    			LTP_LPMa.put(uuid, ProtocolName);	
    		}else
    		{
    			LTP_LPMa.put(uuid, new String());
    		}
    		
    	}
    	LogicalProtocolMap.put(Nodeid, LogicalProtocolMa);
    	LTP_LPMap.put(Nodeid, LTP_LPMa);
    }
    
    

}
