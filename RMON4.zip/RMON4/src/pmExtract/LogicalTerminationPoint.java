package pmExtract;

import java.util.ArrayList;
import java.util.Arrays;

import org.json.JSONArray;

public class LogicalTerminationPoint {
	
	String uuid;
	JSONArray serverLTP;
	JSONArray clientLTP;
	
	public LogicalTerminationPoint(String uuid,JSONArray serverLTP,JSONArray clientLTP) {
        this.uuid = uuid;        
        this.serverLTP = serverLTP;
        this.clientLTP = clientLTP;
    }

}
