package pmExtract;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class LoginToController {

	
	public static Map<String,ArrayList<LogicalTerminationPoint>> LTPArray = new HashMap<String, ArrayList<LogicalTerminationPoint>>();
	
    public static Properties config;
    public static String Controller_username = new String();
    public static String Controller_password = new String();
    public static String Controller_ip = new String();
    public static String Controller_port = new String();
    public static String NodeName = new String();
    public static String Node_Config = new String();
    public static int frequency_sec;
    public static int frequency_min;
    public static int frequency_hours;
    public static long frequency;
    public static int iteration;
    
    public static void loadProperties()
	{
		config = new Properties();
		try {
			 FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/Config.properties");
			 config.load(fis);
			
			 Controller_username = config.getProperty("Controller.username");
			 Controller_password= config.getProperty("Controller.password");
			 
			 Controller_ip = config.getProperty("Controller.ip");
			 Controller_port = config.getProperty("Controller.port");
			 Node_Config =config.getProperty("Node.Config");
			 frequency = (Long.parseLong(config.getProperty("frequency.sec")) * 1000) + 
					 (Long.parseLong(config.getProperty("frequency.min")) * 60000) +
					 (Long.parseLong(config.getProperty("frequency.hour")) * 3600000);
			 iteration = Integer.parseInt(config.getProperty("Iteration"));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception ex)
		{
			
		}
	}
	public static void main1(String Nodeid) throws Exception {
		loadProperties();
    	HttpHost targetHost = new HttpHost(LoginToController.Controller_ip, 8181, "http");
    	CredentialsProvider credsProvider = new BasicCredentialsProvider();
    	credsProvider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(LoginToController.Controller_username, LoginToController.Controller_password));
    	
    	//defining basic authentication
    	AuthCache authCache = new BasicAuthCache();
    	authCache.put(targetHost, new BasicScheme());
    	 
    	// Add AuthCache to the execution context
    	HttpClientContext context = HttpClientContext.create();
    	context.setCredentialsProvider(credsProvider);
    	context.setAuthCache(authCache);
    	HttpClient client = HttpClientBuilder.create().build();
    	
    	//connecting to the server and getting the first request
        try {
        	String URL = new String("http://"+Controller_ip +":" + Controller_port +"/rests/data/network-topology:network-topology/topology=topology-netconf/node="+Nodeid+"/"
					+ "yang-ext:mount/core-model-1-4:control-construct?content="+Node_Config+"&fields=logical-termination-point(uuid;server-ltp;client-ltp)");
        	Main.log("LoginToController : trying to get the server and client LTPs for the node " + Nodeid + " and the URL is" + URL);
        	HttpGet httpGet = new HttpGet(URL);
			HttpResponse response = client.execute(httpGet,context);
            try {
                //System.out.println(response.getStatusLine());
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                StringBuilder builder = new StringBuilder();
                for (String line = null; (line = reader.readLine()) != null;) {
                    builder.append(line).append("\n");
                }
                JSONObject finalResult = new JSONObject(builder.toString());
                //getting core-model
                JSONObject coreModel  = (JSONObject)finalResult.get("core-model-1-4:control-construct");
                //getting LTPs
                JSONArray LTPDetails  = coreModel.getJSONArray("logical-termination-point");
                CreateLogicalTerminationPoint(Nodeid,LTPDetails);
                LogicalProtocolName.getLogicalProtocolName(Nodeid);
                
            } 
            catch(Exception ex)
            {
            	
            }finally {
                
            }
            
        } catch(Exception ex)
        {
        	
        }finally {
            
        }
    }
    
    public static void CreateLogicalTerminationPoint(String Nodeid,JSONArray LTPDetails)
    {
    	ArrayList<LogicalTerminationPoint> LArray = new ArrayList<LogicalTerminationPoint>();
    	for(int i=0;i<LTPDetails.length();i++)
    	{
    		JSONObject json = LTPDetails.getJSONObject(i);
    		if(!json.has("server-ltp") && !json.has("client-ltp"))
    		{
    			LogicalTerminationPoint LTP = new LogicalTerminationPoint(json.getString("uuid"),new JSONArray(),new JSONArray());	
    			LArray.add(LTP);
    		}else if(!json.has("server-ltp"))
    		{
    			LogicalTerminationPoint LTP = new LogicalTerminationPoint(json.getString("uuid"),new JSONArray(),json.getJSONArray("client-ltp"));
    			LArray.add(LTP);
    		}else if(!json.has("client-ltp"))
    		{
    			LogicalTerminationPoint LTP = new LogicalTerminationPoint(json.getString("uuid"),json.getJSONArray("server-ltp"),new JSONArray());
    			LArray.add(LTP);
    		}
    		else
    		{
    			LogicalTerminationPoint LTP = new LogicalTerminationPoint(json.getString("uuid"),json.getJSONArray("server-ltp"),json.getJSONArray("client-ltp"));
    			LArray.add(LTP);
    		}
    	}
    	LTPArray.put(Nodeid, LArray);
    }

}