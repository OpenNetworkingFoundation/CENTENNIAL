package pmExtract;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

public class Main {
	
	public static Properties config;
    public static String Controller_username = new String();
    public static String Controller_password = new String();
    public static String Controller_ip = new String();
    public static String Controller_port = new String();
    public static String NodeName = new String();
    public static String Node_Config = new String();
    public static boolean multiMode = false;
    public static String realTime;
    public static String airInterface;
    public static String[] nodes;
    public static String logFile;
    
    public static void loadProperties()
	{
		config = new Properties();
		try {
			 FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/Config.properties");
			 config.load(fis);
			
			 Controller_username = config.getProperty("Controller.username");
			 Controller_password= config.getProperty("Controller.password");
			 
			 Controller_ip = config.getProperty("Controller.ip");
			 Controller_port = config.getProperty("Controller.port");
			 Controller_port = config.getProperty("Controller.port");
			 NodeName = config.getProperty("Node.Names");
			 if(config.getProperty("Node.all").equals("yes"))
			 {
				 //get all the nodes and store it in the Nodes array
				 nodes = getallNodes().split(",");
			 }else
			 {
			 if(NodeName.contains(","))
			 {
				 multiMode = true; 
				 nodes = NodeName.split(",");
			 }else
			 {
				 String nodes1[] = {NodeName};
				 nodes = nodes1;
			 }
			 }
			 Node_Config =config.getProperty("Node.Config");
			 log("Nodes under test are ");
			 for(int j=0;j<nodes.length;j++)
			 {
			 log(nodes[j]+ ",");
			 }
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Main.log(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Main.log(e.getMessage());
		}
	}
    
    public static void prepareDataSetup()
    {
    	String basePath = getUsersHomeDir() + File.separator + "Rmon_Reports" ;
    	if(!new File(basePath).exists())
	    {
	    	new File(basePath).mkdir();
	    	System.out.println("Directory is created!");
	    }
    	logFile = basePath +  File.separator + "Rmon.log";
    	SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
    	//creating file for real time statistics   
    	realTime = basePath + File.separator + "RealTimeStatistics"
    	        + "_" + formatter.format(new Date())+".csv";
    	airInterface = basePath + File.separator + "Airinterface"
    	        + "_" + formatter.format(new Date())+".csv";
    	WriteToFile realTimeWriter = new WriteToFile(realTime);
    	realTimeWriter.write("Iteration"+ "\t" + "Node id" +"\t\t\t"+ "uuid" +"\t\t" + "Interface Type" +"\t\t"+"Date"+"\t\t"+ "statistics-Is-Up\t" + "interface-Status\t" + 
    			"total-Bytes-Inputt\t" + "total-Bytes-Output\t" + "\n");
    	//creating file for airinterfacecapacity
    	WriteToFile airInterfacewriter = new WriteToFile(airInterface);
    	airInterfacewriter.write("Iteration"+ "\t" + "Node id"+"\t\t\t"+ "uuid" +"\t\t\t"+ "Interface Type" + "\t\t" + "Date" +"\t\t\t"+ "Capacity\n");	
    	realTimeWriter.close();
    	airInterfacewriter.close();
    }
    
    public static void main(String[] args)
    {

    	prepareDataSetup();
    	loadProperties();
    	for(int i=0;i<nodes.length;i++)
    	{
    		int j = i;
    		Thread thread = new Thread() {
    			public void run()
    			{
    				try {
						LoginToController.main1(nodes[j]);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						Main.log(e.getMessage());
					}
    			}
    		};
    		thread.start();
    	}
    }
    
    public static String getallNodes()
    {
        
    RestCall rest = new RestCall(Controller_username,Controller_password,Controller_ip,Integer.parseInt(Controller_port));
	Map<String,Map<String,String>> nodeMap = rest.getMountDetails();
	String nodename = new String();
	for (Map.Entry<String,Map<String,String>> entry : nodeMap.entrySet()) 
	{
		Map map = entry.getValue();											
		
		if(map.get("ConnStatus").equals("connected"))
				{
				if(nodename.isEmpty())
				{
					nodename = (String)map.get("nodeID");
				}else
				{
					nodename = nodename + "," + map.get("nodeID");
				}
				}
	}
	return nodename;
    }
    
    public static String getUsersHomeDir() {
	    String users_home = System.getProperty("user.home");
	    return users_home.replace("\\", "/"); // to support all platforms.
	}
    
    public static void log(String line)
    {
    	WriteToFile log = new WriteToFile(logFile);
    	log.write(new Date()+ "    ");
		log.write(line+"\n");
		log.close();
    }
}
