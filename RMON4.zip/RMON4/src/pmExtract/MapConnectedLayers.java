package pmExtract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;

public class MapConnectedLayers {
	
	public static Map<String,Map<String,String>> MapLANConnectedLayers = new HashMap<String,Map<String,String>>();
	public static Map<String,Map<String,String>> MapWANConnectedLayers = new HashMap<String,Map<String,String>>();
	
	public static void MaptheLayers(String Nodeid,Map<String,String> LogicalProtocolMap)
	{
		Map<String,String> MapWANConnectedLayer = new HashMap<String,String>();
		Map<String,String> MapLANConnectedLayer = new HashMap<String,String>();
		Iterator<String> iter = LogicalProtocolMap.keySet().iterator();
		while(iter.hasNext())
		{
			String uuid = iter.next();
			if(LogicalProtocolMap.get(uuid).contains("LAYER_PROTOCOL_NAME_TYPE_AIR_LAYER") || 
					LogicalProtocolMap.get(uuid).contains("LAYER_PROTOCOL_NAME_TYPE_WIRE_LAYER"))
			{
			String connection = getLayerConnection(Nodeid,uuid);
			//.out.println(connection);
			//Note : connection String in the format LTP --> conn1 --> conn2 : nextconn1 --> nextconn2 
			if(LogicalProtocolMap.get(uuid).contains("LAYER_PROTOCOL_NAME_TYPE_AIR_LAYER"))
			{
				MapWANConnectedLayer.put(uuid, connection);
			}else
			{
				MapLANConnectedLayer.put(uuid, connection);
			}
			}
		}
		MapWANConnectedLayers.put(Nodeid, MapWANConnectedLayer);
		MapLANConnectedLayers.put(Nodeid, MapLANConnectedLayer);
	}
	
	public static String getLayerConnection(String Nodeid,String layerName) {
	    String connection = "";
	    ArrayList<LogicalTerminationPoint> layers = LoginToController.LTPArray.get(Nodeid);
	    Iterator<LogicalTerminationPoint> LTPIter = layers.iterator();
	    while(LTPIter.hasNext())
	    {
	    	LogicalTerminationPoint ltp = LTPIter.next();	    	
	    	if(ltp.uuid.equals(layerName))
	    	{
	    		JSONArray clientLTP = ltp.clientLTP;
	    		if(clientLTP.isEmpty())
	    		{
	    			return layerName + ":";
	    		}
	    		for(int i=0;i<clientLTP.length();i++)
	    		{
	    			connection = connection + layerName + "-->>" + getLayerConnection(Nodeid,clientLTP.getString(i));
	    		}
	    	}
	    }
	    
	    return connection;	    
	}

}
