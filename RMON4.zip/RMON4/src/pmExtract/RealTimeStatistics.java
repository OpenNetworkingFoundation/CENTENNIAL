package pmExtract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RealTimeStatistics {
	
	public static String getRealTimeStatistics(String Nodeid,String uuid)
	{
		String report = new String();
		try {
		Map<String,String> EthLTPDetails = getTheMappedEthernetLayer(Nodeid,uuid);
		Iterator<String> iter = EthLTPDetails.keySet().iterator();
		
		try {
		while(iter.hasNext())
		{
			String LTPid = iter.next();
			String LPid = EthLTPDetails.get(LTPid);
			Main.log("RealTimeStatistics : going to fetch the statistics for the details " + Nodeid + " LTP -" + LTPid + " LP - "+ LPid );
			report = report + GetRealTimeStatistics.getRealTimeStatistics(Nodeid,LTPid, LPid);
		}
		}catch(Exception ex)
		{
			
		}
		
		}catch(Exception e)
		{
			Main.log(e.getMessage());
		}
		return report;
	}
	
	public static Map<String,String> getTheMappedEthernetLayer(String Nodeid,String uuid)
	{
		Map<String,String> EthernetLTPS = new HashMap<String, String>();
		if(MapConnectedLayers.MapLANConnectedLayers.get(Nodeid).containsKey(uuid))
		{
			String connection = MapConnectedLayers.MapLANConnectedLayers.get(Nodeid).get(uuid);
			if(connection.contains(":"))
    		{
    			String[] splitTheConnections = connection.split(":");
    			for(int i=0;i<splitTheConnections.length;i++)
    			{
    				String[] splitLTPs = splitTheConnections[i].split("-->>");
    				for(int j=0;j<splitLTPs.length;j++)
    				{
    					if(LogicalProtocolName.LogicalProtocolMap.get(Nodeid).
    							get(splitLTPs[j]).contains("LAYER_PROTOCOL_NAME_TYPE_ETHERNET_CONTAINER_LAYER"))
    					{
    						String EthernetLTP = splitLTPs[j];
    						String EthernetLP = LogicalProtocolName.LTP_LPMap.get(Nodeid).get(EthernetLTP);
    						EthernetLTPS.put(EthernetLTP,EthernetLP);
    					}
    				}
    			}    			
    		}
			
		}else
		{
			String connection = MapConnectedLayers.MapWANConnectedLayers.get(Nodeid).get(uuid);
			if(connection.contains(":"))
    		{
    			String[] splitTheConnections = connection.split(":");
    			for(int i=0;i<splitTheConnections.length;i++)
    			{
    				String[] splitLTPs = splitTheConnections[i].split("-->>");
    				for(int j=0;j<splitLTPs.length;j++)
    				{
    					if(LogicalProtocolName.LogicalProtocolMap.get(Nodeid).
    							get(splitLTPs[j]).contains("LAYER_PROTOCOL_NAME_TYPE_ETHERNET_CONTAINER_LAYER"))
    					{
    						String EthernetLTP = splitLTPs[j];
    						String EthernetLP = LogicalProtocolName.LTP_LPMap.get(Nodeid).get(EthernetLTP);
    						EthernetLTPS.put(EthernetLTP,EthernetLP);
    					}
    				}
    			}    			
    		}
		}
		return EthernetLTPS;
	}

}
