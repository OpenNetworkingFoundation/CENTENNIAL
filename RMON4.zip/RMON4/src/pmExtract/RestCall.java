package pmExtract;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JOptionPane;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONObject;


public class RestCall {

	public static String userName = new String();
	public static  String password = new String();
	public static String ip = new String();
	public static int port = 8181;

	public RestCall(String userName1, String password1, String ip1, int port1) {
		userName = userName1;
		password = password1;
		port = port1;
		ip = ip1;
	}
	
	public RestCall(String userName) {
		
	}
	public ArrayList<String> getNodeDetails() {
		ArrayList<String> nodeList = new ArrayList();
		try {

			String url = "http://" + ip + ":" + port + "/rests/data/network-topology:network-topology"
					+ "/topology=topology-netconf?content=config&fields=node(node-id)";
			HttpResponse response = ConnectWithRestServer(url);
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			JSONObject finalResult = new JSONObject(builder.toString());

			JSONArray topologyDetails = finalResult.getJSONArray("network-topology:topology");
			JSONObject NodeDetails = topologyDetails.getJSONObject(0);
			JSONArray NodeArray = NodeDetails.getJSONArray("node");
			for (int i = 0; i < NodeArray.length(); i++) {
				JSONObject json = NodeArray.getJSONObject(i);
				String nodeID = json.getString("node-id");
				nodeList.add(nodeID);
			}
		} catch (Exception ex) {
			return nodeList;
		}
		return nodeList;
	}
	
	
	public Map<String,Map<String,String>> getMountDetails() {
		Map<String,Map<String,String>> nodeMap = new HashMap<String,Map<String,String>>();
		try {

			String url = "http://" + ip + ":" + port + "/rests/data/network-topology:network-topology"
					+ "/topology=topology-netconf?content=all&fields=node(node-id;netconf-node-topology:connection-status)";
			HttpResponse response = ConnectWithRestServer(url);
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			JSONObject finalResult = new JSONObject(builder.toString());

			JSONArray topologyDetails = finalResult.getJSONArray("network-topology:topology");
			JSONObject NodeDetails = topologyDetails.getJSONObject(0);
			JSONArray NodeArray = NodeDetails.getJSONArray("node");
			for (int i = 0; i < NodeArray.length(); i++) {
				JSONObject json = NodeArray.getJSONObject(i);
				String nodeID = json.getString("node-id");
				String ConnStatus = json.getString("netconf-node-topology:connection-status");
				Map<String,String> map = new HashMap();
				map.put("nodeID", nodeID);
				map.put("ConnStatus", ConnStatus);
				
				nodeMap.put(nodeID,map);
			}
		} catch (Exception ex) {
			return nodeMap;
		}
		return nodeMap;
	}

	public HttpResponse ConnectWithRestServer(String url) {
		HttpHost targetHost = new HttpHost(ip, port, "http");
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(userName, password));

		// defining basic authentication
		AuthCache authCache = new BasicAuthCache();
		authCache.put(targetHost, new BasicScheme());

		// Add AuthCache to the execution context
		HttpClientContext context = HttpClientContext.create();
		context.setCredentialsProvider(credsProvider);
		context.setAuthCache(authCache);
		HttpClient client = HttpClientBuilder.create().build();

		// connecting to the server and getting the first request
		try {
			HttpGet httpGet = new HttpGet(url);
			HttpResponse response = client.execute(httpGet, context);
			return response;
		} catch (Exception ex) {
			return null;
		}
	}

	public String getResponse(String url) {

		HttpResponse response = ConnectWithRestServer(url);
		if (response.getStatusLine().toString().contains("200")) {
			return "pass";
		} else {
			return "fail";
		}

	}

}
