package rmon;
/*
 * @author : Prathiba Jeevan
 * purpose : perform the RMON extractions 
 * step 1 : Read the config.properties file and do basic directory setup
 * step 2 :	Get the number of nodes 
 * step 3 : Update the LTP-LP,ServerClientLTPs, 
 * step 4 : Update equipment and vendor details repository
 * step 5 : Trigger separate threads to calculate Rmon values
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.database.ServerClientLTPs;
import rmon.database.WriteToFile;
import rmon.logger.*;

public class RMON {
	
	
	public static ArrayList<String> nodes = new ArrayList<String>();
	public static List<String> airInterfaceHeader;
	public static List<String> realTimeHeader;
	
		
	public static void main(String[] args)
	{
		loadConfigFile();
		loadNodeDetails();
		basicFileSetup();
		updateFileHeaders();
		startProcess();
	}
	
	
	public static void loadConfigFile()
	{
		try {
		Properties config = new Properties();
		FileInputStream configFile = new FileInputStream(System.getProperty("user.dir") + "/Config.properties");
		config.load(configFile);
		// load the properties and store in configuration
		new Configuration(config);
		}catch(FileNotFoundException ex)
		{
			Log.Error("File config.properties is not available in the user directory location");
			Log.Error(ex);
		}catch(IOException ex)
		{
			Log.Error("Issues in reading/loading the config.properties file");
			Log.Error(ex);
		}
	}
	
	public static void loadNodeDetails()
	{
		if(Configuration.Nodeall.equals("yes"))
		 {
			 //get all the nodes from the topology and perform the operations
			 nodes = RestOperations.getallNodesfromTopology();
		 }else
		 {
		 if(Configuration.NodeName.contains(","))
		 {
			 nodes = new ArrayList<String>(Arrays.asList(Configuration.NodeName.split(",")));
		 }else
		 {
			 nodes.add(Configuration.NodeName);
		 }
		 }
	}
	
	public static void basicFileSetup()
	{
		File baseDirectory = new File(getUsersHomeDir());
		if (!baseDirectory.exists()) {
			baseDirectory.mkdir();
		}
		Configuration.DBbasePath = getUsersHomeDir() + File.separator + "RMonDataBase";
		Configuration.DBPath = Configuration.DBbasePath + File.separator + Configuration.ipAddress.replace(".", "_");
		Configuration.RmonBasePath = getUsersHomeDir() + File.separator + "RMonReports";
		Configuration.RmonReportPath = Configuration.RmonBasePath + File.separator + Configuration.ipAddress.replace(".", "_");
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
		Configuration.airInterfaceReport = Configuration.RmonReportPath + File.separator + "Airinterface" + "_" + formatter.format(new Date())+".csv";
		Configuration.StatistisReport = Configuration.RmonReportPath + File.separator + "RealTimeStatistics" + "_" + formatter.format(new Date())+".csv";
		File DBbasePath = new File(Configuration.DBbasePath);
		File RmonBasePath = new File(Configuration.RmonBasePath);
		File DataBasePath = new File(Configuration.DBPath);
		File RMonBasePath = new File(Configuration.RmonReportPath);
		
		if (!DBbasePath.exists()) {
			DBbasePath.mkdir();
		}
		if (!RmonBasePath.exists()) {
			RmonBasePath.mkdir();
		}			
		if (!DataBasePath.exists()) {
			DataBasePath.mkdir();
		}
		if (!RMonBasePath.exists()) {
			RMonBasePath.mkdir();
		}		
	}
	
	public static void updateFileHeaders()
	{
		String[] statistics = {"Iteration","Node-id","Connection-Status","Vendor","Equipment","uuid","Interface-Type","Date","Statistics-Is-Up","Interface-Status",
    			"total-Bytes-Input","total-Bytes-Output","Input Delta","Output Delta","Input Utilization","Output Utilization","Response-Code"};
		realTimeHeader = Arrays.asList(statistics);	
		WriteToFile statisticsWrite = new WriteToFile(Configuration.StatistisReport);
		statisticsWrite.writeToHeader(realTimeHeader);
		
		String[] airInterface = {"Iteration","Node id","Connection Status","Vendor","eqpt","uuid","Interface Type", "Date",
				"Capacity" , "Failure Reason", "Interface-status Response","current-Transmission Response","Transmission-mode-List Response",
				"CurrentTransmissionMode","ChannelBandwidth","codeRate","modulationScheme","symbolRateReductionFactor"};
    	airInterfaceHeader = Arrays.asList(airInterface);	
    	WriteToFile airInterfaceWrite = new WriteToFile(Configuration.airInterfaceReport);
    	airInterfaceWrite.writeToHeader(airInterfaceHeader);
	}
	
		
	public static void startProcess()
	{
		Iterator<String> iterator = nodes.iterator();
		while(iterator.hasNext())
		{
			RMonProcess rmonProcess = new RMonProcess();
			rmonProcess.start(iterator.next());
		}
	}
	
	public static String getUsersHomeDir() {
		String users_home = System.getProperty("user.home");		
		return users_home.replace("\\", "/")+ File.separator + "RMON"; // to support all platforms.
	}

}
