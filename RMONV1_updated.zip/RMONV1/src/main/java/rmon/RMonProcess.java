package rmon;

import java.util.ArrayList;
import java.util.Iterator;

import rmon.airInterface.AirInterfaceCapacity;
import rmon.common.Configuration;
import rmon.database.DataBase;

/* Perform air interface capacity calculation , 
 * get airinterface,wire interface uuids
 * get LPLTP uuids
 * get server client LTP
 * get vendor details
 * get 
 * 
 */

import rmon.database.Equipment;
import rmon.database.LTPLPs;
import rmon.database.LtpAugment;
import rmon.database.ServerClientLTPs;
import rmon.database.Vendor;

public class RMonProcess {
	
	public String DBStatus = new String();

	public void start(String nodeId) {
		loadFromDataBase(nodeId);
		//if(!DBStatus.equals("fail"))
		//{
		ArrayList<LTPLPs> LTPArray = DataBase.LTPLPs.get(nodeId);
		if (LTPArray != null) {
			Iterator<LTPLPs> iterator = LTPArray.iterator();
			while (iterator.hasNext()) {
				LTPLPs LTP = iterator.next();
				String protocol = LTPLPs.getProtocalName(nodeId, LTP.uuid);
				if (protocol.equals(Configuration.airInterface)) {
					AirInterfaceCapacity capacityCalculation = new AirInterfaceCapacity(nodeId, LTP.uuid, LTP.lpId);
					capacityCalculation.start();
				}

			}
		}
		//}
	}

	public void loadFromDataBase(String nodeId) {		
		ServerClientLTPs.loadFromDB(nodeId,this);
		LtpAugment.loadFromDB(nodeId,this);
		Equipment.loadFromDB(nodeId,this);
		Vendor.loadFromDB(nodeId,this);
	}
}
