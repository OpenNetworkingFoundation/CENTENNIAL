package rmon.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.params.HttpParams;

import rmon.exception.HttpRequestFailure;
import rmon.logger.Log;

public class RestCall {
	public String url = new String();

	public RestCall(String url) {
		this.url = url;
	}

	public HttpResponse SendRequestTest() {

		HttpResponse response = null;
		HttpHost targetHost = new HttpHost(Configuration.ipAddress, Configuration.port, "http");
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(AuthScope.ANY,
				new UsernamePasswordCredentials(Configuration.userName, Configuration.password));

		// defining basic authentication
		AuthCache authCache = new BasicAuthCache();
		authCache.put(targetHost, new BasicScheme());

		// Add AuthCache to the execution context
		HttpClientContext context = HttpClientContext.create();
		context.setCredentialsProvider(credsProvider);
		context.setAuthCache(authCache);
		HttpClient client = HttpClientBuilder.create().build();
				
		// connecting to the server and getting the first request
		try {
			
			HttpGet httpGet = new HttpGet(url);
			httpGet.setHeader("User-Agent", "Mozilla");
			response = client.execute(httpGet, context);
		} catch (Exception ex) {
			Log.Error("Exception bkup1 occured during a restcall");
			Log.Error(ex);
		}
		if (response == null) {
			Log.Error("Restcallbkup didnt executed successfully for the url " + url);
		}
		if (response != null && response.getStatusLine().getStatusCode() != 200) {
			try {
				
				Log.Error("response code is not 200 for the url " + url );
			} catch (Exception ex) {
				Log.Error("Issues in reading the response of the non 200 execution of url " + url);
			}
		}
		return response;
	}
	public HttpResponse SendRequest() {

		HttpResponse response = null;
		HttpHost targetHost = new HttpHost(Configuration.ipAddress, Configuration.port, "http");
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(AuthScope.ANY,
				new UsernamePasswordCredentials(Configuration.userName, Configuration.password));

		// defining basic authentication
		AuthCache authCache = new BasicAuthCache();
		authCache.put(targetHost, new BasicScheme());

		// Add AuthCache to the execution context
		HttpClientContext context = HttpClientContext.create();
		context.setCredentialsProvider(credsProvider);
		context.setAuthCache(authCache);
		HttpClient client = HttpClientBuilder.create().build();

		// connecting to the server and getting the first request
		try {
			HttpGet httpGet = new HttpGet(url);
			response = client.execute(httpGet, context);
		} catch (Exception ex) {
			Log.Error("Exception occured during a restcall");
			Log.Error(ex);
		}
		if (response == null) {
			Log.Error("Restcall didnt executed successfully for the url " + url);
		}
		if (response != null && response.getStatusLine().getStatusCode() != 200) {
			try {
				
				Log.Error("response code is not 200 for the url " + url );
			} catch (Exception ex) {
				Log.Error("Issues in reading the response of the non 200 execution of url " + url);
			}
		}
		return response;
	}

}
