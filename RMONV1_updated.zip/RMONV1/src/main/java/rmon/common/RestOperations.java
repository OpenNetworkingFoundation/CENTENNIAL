package rmon.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import rmon.exception.HttpRequestFailure;
import rmon.logger.Log;

public class RestOperations {

	public static ArrayList<String> getallNodesfromTopology() {
		ArrayList<String> nodenames = new ArrayList<String>();
		try {
			RestCall restcall = new RestCall(RestUrls.getNodeNames);
			HttpResponse response = restcall.SendRequest();
			if (response == null || response.getStatusLine().getStatusCode() != 200) {
				return nodenames;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			JSONObject finalResult = new JSONObject(builder.toString());

			JSONArray topologyDetails = finalResult.getJSONArray("network-topology:topology");
			JSONObject NodeDetails = topologyDetails.getJSONObject(0);
			JSONArray NodeArray = NodeDetails.getJSONArray("node");
			int count = 0;
			for (int i = 0; i < NodeArray.length(); i++) {
				
				JSONObject json = NodeArray.getJSONObject(i);
				String nodeName = json.getString("node-id");
				String ConnStatus = json.getString("netconf-node-topology:connection-status");
				if (nodeName != null && !nodeName.isEmpty() && ConnStatus.equalsIgnoreCase("connected")) {
					nodenames.add(nodeName);
				}else if(nodeName != null && !nodeName.isEmpty() && !ConnStatus.equalsIgnoreCase("connected"))
				{
					Log.info(nodeName + " node not connected");
					count = count + 1;
				}
			}
			Log.info("Number of not connected nodes :" + count);
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the getallNodesfromTopology");
			Log.Error(ex);
		}
		return nodenames;
	}
	
	
	public static JSONArray getLogicalTerminationPoint(String nodeId) {
		JSONArray jsonResponse = null;
		try {
			RestCall restcall = new RestCall(RestUrls.getLogicalTerminationPoint.replace("<<nodeId>>", nodeId));
			HttpResponse response = restcall.SendRequest();
			if (response == null || response.getStatusLine().getStatusCode() != 200) {
				return jsonResponse;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			JSONObject finalResult = new JSONObject(builder.toString());
			JSONObject coreModel = (JSONObject) finalResult.get("core-model-1-4:control-construct");
			jsonResponse = coreModel.getJSONArray("logical-termination-point");
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the logical-termination-point for the nodeid "+nodeId);
			Log.Error(ex);
		}
		return jsonResponse;
	}
	
	public static JSONObject getLtpAugment(String nodeId,String uuid) {
		JSONObject jsonResponse = null;
		try {
			RestCall restcall = new RestCall(RestUrls.getLtpAugment.replace("<<nodeId>>", nodeId).replace("<<uuid>>", uuid));
			HttpResponse response = restcall.SendRequest();
			if (response == null || response.getStatusLine().getStatusCode() != 200) {
				return jsonResponse;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}			
			JSONObject finalResult = new JSONObject(builder.toString());
			jsonResponse = (JSONObject) finalResult.get("ltp-augment-1-0:ltp-augment-capability");			
			
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the LtpAugment for the nodeid "+nodeId);
			Log.Error(ex);
		}
		return jsonResponse;
	}
	
	public static JSONArray getEquipment(String nodeId) {
		JSONArray jsonResponse = null;
		try {
			RestCall restcall = new RestCall(RestUrls.getEquipment.replace("<<nodeId>>", nodeId));
			HttpResponse response = restcall.SendRequest();
			if (response == null || response.getStatusLine().getStatusCode() != 200) {
				return jsonResponse;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			JSONObject finalResult = new JSONObject(builder.toString());
			JSONObject coreModel = (JSONObject) finalResult.get("core-model-1-4:control-construct");
			jsonResponse = coreModel.getJSONArray("equipment");
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the equipment for the nodeid "+nodeId);
			Log.Error(ex);
		}
		return jsonResponse;
	}
	
	public static RmonResponse getAirInterfaceStatusAttribute(String nodeId,String uuid,String lpId,String attribute) {
		RmonResponse jsonResponse = null;
		try {
			RestCall restcall = new RestCall(RestUrls.getAirInterfaceStatusAttribute.replace("<<nodeId>>", nodeId).replace("<<uuid>>", uuid)
					.replace("<<lpId>>", lpId).replace("<<attribute>>", attribute));
			HttpResponse response = restcall.SendRequest();
			if (response == null)
			{
				jsonResponse = new RmonResponse("no response received",-1,"fail");
				return jsonResponse;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			if (response.getStatusLine().getStatusCode() != 200) {
				jsonResponse = new RmonResponse(builder.toString(),response.getStatusLine().getStatusCode(),"fail");
				return jsonResponse;
			}
			JSONObject finalResult = new JSONObject(builder.toString());
			jsonResponse = new RmonResponse(finalResult.getString("air-interface-2-0:"+attribute),response.getStatusLine().getStatusCode(),"pass");
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the equipment for the nodeid "+nodeId);
			Log.Error(ex);
		}
		return jsonResponse;
	}
	
	public static RmonResponse getAirInterfaceTransmissionModeList(String nodeId,String uuid,String lpId) {
		RmonResponse jsonResponse = null;
		try {
			RestCall restcall = new RestCall(RestUrls.getTransmissionModeList.replace("<<nodeId>>", nodeId).replace("<<uuid>>", uuid)
					.replace("<<lpId>>", lpId));
			HttpResponse response = restcall.SendRequest();
			if (response == null) {
				jsonResponse = new RmonResponse("no response received",-1,"fail");
				return jsonResponse;
			}
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			StringBuilder builder = new StringBuilder();
			for (String line = null; (line = reader.readLine()) != null;) {
				builder.append(line).append("\n");
			}
			if (response.getStatusLine().getStatusCode() != 200) {
				jsonResponse = new RmonResponse(builder.toString(),response.getStatusLine().getStatusCode(),"fail");
				return jsonResponse;
			}
			JSONObject finalResult = new JSONObject(builder.toString());
			// getting core-model
			JSONObject coreModel = (JSONObject) finalResult.get("air-interface-2-0:air-interface-pac");
			// getting capabilities
			JSONObject capability = (JSONObject) coreModel.get("air-interface-capability");
			// getting transmission-mode-list
			jsonResponse = new RmonResponse(capability.getJSONArray("transmission-mode-list"),response.getStatusLine().getStatusCode(),"pass");
		} catch (Exception ex) {
			Log.Error("After executing the rest command , issues in processing the logical-termination-point for the nodeid "+nodeId);
			Log.Error(ex);
		}
		return jsonResponse;
	}

}
