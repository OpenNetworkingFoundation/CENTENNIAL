package rmon.common;

public class RestUrls {
	
	public static String connectionStatus = "http://"+ Configuration.ipAddress +":"+ Configuration.port +"/rests/data/network-topology:network-topology"
			+ "/topology=topology-netconf?content=all&fields=node(node-id;netconf-node-topology:connection-status)";
	
	public static String getNodeNames = "http://"+ Configuration.ipAddress +":"+ Configuration.port +"/rests/data/network-topology:network-topology"
			+ "/topology=topology-netconf?content=all&fields=node(node-id;netconf-node-topology:connection-status)";
	
	public static String getLogicalTerminationPoint = "http://" + Configuration.ipAddress + ":" + Configuration.port + "/rests/data/network-topology:network-topology/topology=topology-netconf/node=<<nodeId>>/"
			+ "yang-ext:mount/core-model-1-4:control-construct?content=" + Configuration.Node_Config + "&fields=logical-termination-point";
	
	public static String getLtpAugment = "http://" + Configuration.ipAddress + ":" + Configuration.port +"/rests/data/network-topology:network-topology" + "/topology=topology-netconf/node=<<nodeId>>"
	+ "/yang-ext:mount/core-model-1-4:control-construct/logical-termination-point=<<uuid>>/ltp-augment-pac/ltp-augment-capability";
	
	public static String getEquipment = "http://"+ Configuration.ipAddress +":" + Configuration.port +"/rests/data/network-topology:network-topology/topology=topology-netconf/node=<<nodeId>>" 
			+ "/yang-ext:mount/core-model-1-4:control-construct?content=config&fields=equipment";
	
	public static String getTransmissionModeList = "http://" + Configuration.ipAddress	+ ":" +Configuration.port + "/rests/data/network-topology:network-topology/topology=topology-netconf/node=<<nodeId>>"
			 + "/yang-ext:mount/core-model-1-4:control-construct/logical-termination-point=<<uuid>>/layer-protocol=<<lpId>>/air-interface-2-0:air-interface-pac?"
			 + "fields=air-interface-capability(transmission-mode-list)";
	
	public static String getAirInterfaceStatusAttribute = "http://"+ Configuration.ipAddress +":" + Configuration.port + "/rests/data/network-topology:network-topology/topology=topology-netconf/node=" 
			+ "<<nodeId>>/yang-ext:mount/core-model-1-4:control-construct/logical-termination-point=" 
			+ "<<uuid>>/layer-protocol=<<lpId>>/air-interface-2-0:air-interface-pac/air-interface-status/<<attribute>>";
	
}
