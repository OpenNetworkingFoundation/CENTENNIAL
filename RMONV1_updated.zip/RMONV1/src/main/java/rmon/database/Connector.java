package rmon.database;

import org.json.JSONArray;

public class Connector {
	
	public String nodeid;
	public String uuid;
	public String name;
	
	public Connector(String nodeid, String uuid, String name) {
		this.nodeid = nodeid;
		this.uuid = uuid;
		this.name = name;
	}
	
	
	

}
