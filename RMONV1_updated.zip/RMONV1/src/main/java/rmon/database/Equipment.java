package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.RMonProcess;
import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.logger.Log;

public class Equipment {
	String nodeId;
	String uuid;
	String manufacturerName;
	public static String file = Configuration.DBPath + File.separator + "Equipment";

	public Equipment(String nodeId, String uuid, String manufacturerName) {
		
		this.nodeId=nodeId;
		this.uuid = uuid;
		this.manufacturerName = manufacturerName;
	}

	/*
	 * In the file , details will be in the format
	 * nodeId:::uuid:::[connectors(localId,contained-holder/name/value)]:::[
	 * equipment(uuid,actual-equipment/manufacturer-name)]
	 */
	public static void loadFromDB(String nodeId,RMonProcess process) {
		try {
			ArrayList<Equipment> equipmentDetails = new ArrayList<Equipment>();
			ArrayList<Connector> connectorDetails = new ArrayList<Connector>();
			File equipmentFile = new File(file);
			if (equipmentFile.exists()) {
				Scanner scan = new Scanner(equipmentFile);
				while (scan.hasNext()) {
					String content = scan.nextLine();
					String[] details = content.split(":::");
					String type = details[0];
					String nodeName = details[1];

					if (nodeName.equals(nodeId)) {
						String uuid = new String();
						if(details.length > 2)
						{
							uuid = details[2];
						}
						String name = new String();
						if(details.length > 3)
						{
						name = details[3];
						}
						if(type.equals("Connector"))
						{
							Connector connector = new Connector(nodeId, uuid, name);
							connectorDetails.add(connector);	
						}else
						{
							Equipment equipment = new Equipment(nodeId, uuid, name);
							equipmentDetails.add(equipment);
						}
						
					}
				}
				scan.close();
			}
			if (equipmentDetails.size() != 0) {
				DataBase.equipments.put(nodeId, equipmentDetails);
			} 
			if (connectorDetails.size() != 0) {
				DataBase.connectors.put(nodeId, connectorDetails);
			} 
			if(equipmentDetails.size() ==0 || connectorDetails.size()==0)
			{
				loadFromController(nodeId,process);
			}
			
		} catch (Exception ex) {
			Log.Error("exception in retrieving server-ltp details from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}

	public static void loadFromController(String nodeId,RMonProcess process) {
		JSONArray response = RestOperations.getEquipment(nodeId);
		if(response!=null)
		{
		loadFromResponse(nodeId, response,process);
		}
	}

	public static void loadFromResponse(String nodeId, JSONArray response,RMonProcess process) {
		
		ArrayList<Connector> connectorArray = new ArrayList<Connector>();
		ArrayList<Equipment> equipmentArray = new ArrayList<Equipment>();
		try {
		for(int i=0;i<response.length();i++)
    	{

			WriteToFile EquipmentWriter = new WriteToFile(file);
    		JSONObject eqptJson = response.getJSONObject(i);            		
    		if(eqptJson.has("connector"))
    		{
    			JSONArray conJson = eqptJson.getJSONArray("connector");
    			for(int k=0;k<conJson.length();k++)
            	{
    				JSONObject json = conJson.getJSONObject(k);
    				if(json.has("local-id")&&json.has("name"))
        			{
        			String localId = json.getString("local-id");
        			String name = "not-defined";
        			JSONArray nameList = json.getJSONArray("name");
        			for(int j=0;j<nameList.length();j++)
                	{
        				JSONObject value = nameList.getJSONObject(j);
        				name = value.getString("value");
                	}
        			Connector connector = new Connector(nodeId,localId,name);
        			connectorArray.add(connector);
        			EquipmentWriter.write("Connector" + ":::" + nodeId + ":::" +  localId + ":::" +name );
        			}    				
            	}	
    		}
    	}
		}catch(Exception ex)
		{
			Log.Error("exception in processing the response for loading connector details from Equipment container" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
		try
		{
		for(int i=0;i<response.length();i++)
        {
			WriteToFile EquipmentWriter = new WriteToFile(file);
        	try
        	{
        	String vendorName = "not-available";
        		String uuid = response.getJSONObject(i).getString("uuid");
        		if(response.getJSONObject(i).getJSONObject("actual-equipment").
        				getJSONObject("manufactured-thing").getJSONObject("manufacturer-properties").has("manufacturer-name"))
        		{
        		vendorName = response.getJSONObject(i).getJSONObject("actual-equipment").
        				getJSONObject("manufactured-thing").getJSONObject("manufacturer-properties").getString("manufacturer-name");
        		}
        		Equipment equipment = new Equipment(nodeId,uuid,vendorName);
    			equipmentArray.add(equipment);
    			EquipmentWriter.write("Equipment" + ":::" +nodeId + ":::" + uuid + ":::" + vendorName);
        	}catch(Exception ex)
        	{
        		Log.Error("Some issues in evaluating the equipment manufacturer properties for the nodeID "+nodeId);
        		Log.Error(ex);
        	}
        }
		}catch(Exception ex)
		{
			Log.Error("exception in processing the response for loading equipment details from Equipment container" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
		
		DataBase.equipments.put(nodeId, equipmentArray);
		DataBase.connectors.put(nodeId, connectorArray);
	}
	
	public static String getEquipmentDetailsForLTPAugment(String nodeId,String ltpEquipmentId)
	{
		ArrayList<Equipment> equipments = DataBase.equipments.get(nodeId);
		Iterator<Equipment> iterator = equipments.iterator();
		while(iterator.hasNext())
		{
			Equipment equipment = iterator.next();
			if(equipment.uuid.equals(ltpEquipmentId))
			{
				return equipment.manufacturerName;
			}
		}
		return "not-defined";
	}

}
