package rmon.database;

public enum LayerProtocolName {
	
	AirInterface("air-interface-2-0:LAYER_PROTOCOL_NAME_TYPE_AIR_LAYER"), 
	WireInterface("wire-interface-2-0:LAYER_PROTOCOL_NAME_TYPE_WIRE_LAYER"), 
	EthernetInterce("ethernet-container-2-0:LAYER_PROTOCOL_NAME_TYPE_ETHERNET_CONTAINER_LAYER");
	
	private String name;
	
	private LayerProtocolName(String name)
	{
		this.name = name;
	}
	
	
}
