package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.RMonProcess;
import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.logger.Log;

public class LtpAugment {
	
	public String nodeId;
	public String uuid;
	public String connectors;
	public JSONArray equipment;
	public static String file = Configuration.DBPath + File.separator + "LtpAugment";
	
	public LtpAugment(String nodeId,String uuid,String connectors,JSONArray equipment)
	{
		this.nodeId = nodeId;
		this.uuid = uuid;
		this.equipment = equipment;
		this.connectors = connectors;
	}
	
	/*
	 * In the file , details will be in the format nodeId:::uuid:::connector:::equipment(jsonArray)
	 */
	public static void loadFromDB(String nodeId,RMonProcess process)
	{
		try {
			ArrayList<LtpAugment> LtpAugmentArray = new ArrayList<LtpAugment>();
			File ltpAugmentWriter = new File(file);
			if (ltpAugmentWriter.exists()) {				
				Scanner scan = new Scanner(ltpAugmentWriter);
				while (scan.hasNext()) {
					String content = scan.nextLine();
					String[] details = content.split(":::");
					String nodeName = details[0];

					if (nodeName.equals(nodeId)) {
						String uuid = details[1];
						String connector = details[2];
						String equipment = details[3];
						JSONArray equipmentArray = new JSONArray(equipment);
						LtpAugment LTP = new LtpAugment(nodeId,uuid, connector, equipmentArray);
						LtpAugmentArray.add(LTP);
					}
				}
				scan.close();				
			}
			if (LtpAugmentArray.size() != 0) {
				DataBase.ltpAugment.put(nodeId, LtpAugmentArray);
			}
			else
			{
				loadFromController(nodeId,process);
			}
		} catch (Exception ex) {
			Log.Error("exception in retrieving server-ltp details from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
	
	public static void loadFromController(String nodeId,RMonProcess process)
	{
		ArrayList<String> uuids = LTPLPs.getLTPs(nodeId);
		Iterator<String> iterator = uuids.iterator();
		while(iterator.hasNext())
		{
			String uuid = iterator.next();
			JSONObject response = RestOperations.getLtpAugment(nodeId, uuid);
			if(response != null)
			{
			loadFromResponse(nodeId,uuid,response,process);	
			}
		}
		
	}
	
	public static void loadFromResponse(String nodeId,String uuid,JSONObject response,RMonProcess process)
	{
		try {
		ArrayList<LtpAugment> ltpAugment = new ArrayList<LtpAugment>();
		String connector = new String();
		JSONArray equipments = new JSONArray();
		if(response.has("connector"))
		{connector = response.getString("connector");}
		if(response.has("equipment"))		
		{equipments = response.getJSONArray("equipment");}
		
		LtpAugment ltp = new LtpAugment(nodeId, uuid, connector, equipments);
		if(DataBase.ltpAugment.containsKey(nodeId))
		{
			ltpAugment = DataBase.ltpAugment.get(nodeId);
			ltpAugment.add(ltp);
			DataBase.ltpAugment.put(nodeId, ltpAugment);
		}else
		{
			ltpAugment.add(ltp);
			DataBase.ltpAugment.put(nodeId, ltpAugment);
		}
		WriteToFile ltpAugmentWriter = new WriteToFile(file);
		ltpAugmentWriter.write(nodeId + ":::" + uuid + ":::" + connector + ":::" + equipments.toString());		
		}catch(Exception ex)
		{
			Log.Error("exception in loading the ltpAugment details from controller" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
	
	public static LtpAugment getLtpAugment(String nodeId,String uuid)
	{
		ArrayList<LtpAugment> ltpAugment = DataBase.ltpAugment.get(nodeId);
		if(ltpAugment!=null)
		{
		Iterator<LtpAugment> ltpIter = ltpAugment.iterator();
		while(ltpIter.hasNext())
		{
			LtpAugment ltp = ltpIter.next();
			if(ltp.uuid.equals(uuid))
			{
				return ltp;
			}
		}
		}
		return null;
	}
	

}
