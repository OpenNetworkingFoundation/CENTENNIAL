package rmon.database;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.RMonProcess;
import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.logger.Log;

public class ServerClientLTPs {
	
	public String nodeId;
	public String uuid;
	public JSONArray serverLTP;
	public JSONArray clientLTP;
	public static String file = Configuration.DBPath + File.separator + "ClientServerLTPs";
	
	public ServerClientLTPs(String nodeId,String uuid,JSONArray serverLTP,JSONArray clientLTP) {
		this.nodeId = nodeId;
        this.uuid = uuid;        
        this.serverLTP = serverLTP;
        this.clientLTP = clientLTP;
    }

	@Override
	public String toString() {
		return "ServerClientLTPs [uuid=" + uuid + ", serverLTP=" + serverLTP + ", clientLTP=" + clientLTP + "]";
	}
	
	/*
	 * In the file , details will be in the format nodeId:::uuid:::clientLTP:::ServerLTP
	 */
	public static void loadFromDB(String nodeId,RMonProcess process)
	{
		try {
			ArrayList<ServerClientLTPs> LTPArray = new ArrayList<ServerClientLTPs>();
			File serverClientLtpFile = new File(file);
			if (serverClientLtpFile.exists()) {				
				Scanner scan = new Scanner(serverClientLtpFile);
				while (scan.hasNext()) {
					String content = scan.nextLine();
					String[] details = content.split(":::");
					String nodeName = details[0];

					if (nodeName.equals(nodeId)) {
						String uuid = details[1];
						String serverLTP = details[2];
						String clientLTP = details[3];
						JSONArray serverLTPArray = new JSONArray(serverLTP);
						JSONArray clientLTPArray = new JSONArray(clientLTP);
						ServerClientLTPs LTP = new ServerClientLTPs(nodeId,uuid, serverLTPArray, clientLTPArray);
						LTPArray.add(LTP);
					}
				}
				scan.close();				
			}
			if (LTPArray.size() != 0) {
				DataBase.ServerClientLTPs.put(nodeId, LTPArray);
				LTPLPs.loadFromDB(nodeId);
			}
			else
			{
				loadFromController(nodeId,process);
			}
		} catch (Exception ex) {
			Log.Error("exception in retrieving server-ltp details from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
	
	public static void loadFromController(String nodeId,RMonProcess process)
	{
		JSONArray response = RestOperations.getLogicalTerminationPoint(nodeId);
		if(response!=null)
		{
		loadFromResponse(nodeId,response,process);
		LTPLPs.loadFromResponse(nodeId, response);
		}
	}
	
	public static void loadFromResponse(String nodeId,JSONArray response,RMonProcess process)
	{
		try {
		ArrayList<ServerClientLTPs> LArray = new ArrayList<ServerClientLTPs>();		
		for (int i = 0; i < response.length(); i++) {
			WriteToFile serverClientLTPWriter = new WriteToFile(file);
			String uuid = "";
			JSONArray serverLTP = new JSONArray();
			JSONArray clientLTP = new JSONArray();
			JSONObject json = response.getJSONObject(i);
			if (!json.has("server-ltp") && !json.has("client-ltp")) {
				uuid = json.getString("uuid");

			} else if (!json.has("server-ltp")) {
				uuid = json.getString("uuid");
				clientLTP = json.getJSONArray("client-ltp");

			} else if (!json.has("client-ltp")) {
				uuid = json.getString("uuid");
				serverLTP = json.getJSONArray("server-ltp");

			} else {
				uuid = json.getString("uuid");
				serverLTP = json.getJSONArray("server-ltp");
				clientLTP = json.getJSONArray("client-ltp");

			}
			ServerClientLTPs LTP = new ServerClientLTPs(nodeId,uuid, serverLTP, clientLTP);
			LArray.add(LTP);
			serverClientLTPWriter.write(nodeId + ":::" + uuid + ":::" + serverLTP.toString() + ":::" + clientLTP.toString());
		}
		DataBase.ServerClientLTPs.put(nodeId, LArray);
		}catch(Exception ex)
		{
			Log.Error("exception in processing the server-ltp details from controller" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}

}
