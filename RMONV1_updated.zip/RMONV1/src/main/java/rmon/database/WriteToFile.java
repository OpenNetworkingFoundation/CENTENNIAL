package rmon.database;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import rmon.logger.Log;

public class WriteToFile {
	
	File file;
	FileWriter myWriter;
	
	public WriteToFile(String fileName)
	{
		try
		{
		file = new File(fileName);
		myWriter = new FileWriter(file.getAbsoluteFile(),true);
		}catch(Exception ex)
		{
			Log.Error(ex.getMessage());
		}
	}
	
	public void writeToHeader(List<String> line)
	{
		try {
			String header = new String();
			Iterator<String> iterator = line.iterator();
			while(iterator.hasNext())
			{
				header = header + iterator.next() + "\t";
			}
			
			myWriter.write(header + "\n");
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.Error(e.getMessage());
			}
	}
	
	public void write(String line)
	{
		try {
			myWriter.write(line+"\n");
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.Error(e.getMessage());
			}
	}
	

}
