package rmon.realTimeStatistics;

import java.util.Map;

/*
 * @author : Prathiba Jeevan
 * purpose : calculate the ethernet utilization , 
 * step 1 :	Find out the mapped ethernet-interface, 
 * step 2 : get the total-bytes-input/output from the status
 * step 3 : calculate the delta and the utilization 
 * 
 * 
 */

public class RealTimeStatistics extends Thread{
	
	String nodeId = new String();
	String uuid = new String();
	
	public RealTimeStatistics(String nodeId,String uuid)
	{
		this.nodeId = nodeId;
		this.uuid = uuid;
	}
	
	public String getMappedEthernet()
	{
		return null;
	}
	
	public boolean checkIfInterfaceStatusIsUp(String ethernetUuid)
	{
		return false;
	}
	
	public Map<String,String> getTotalBytes(String ethernetUuid)
	{
		return null;
	}
	
	public Map<String,String> getStatistics()
	{
		String ethernetUuid = getMappedEthernet();
		if(checkIfInterfaceStatusIsUp(ethernetUuid))
		{
			Map<String,String> TotalBytes = getTotalBytes(ethernetUuid);
		}
		return null;
	}

}
