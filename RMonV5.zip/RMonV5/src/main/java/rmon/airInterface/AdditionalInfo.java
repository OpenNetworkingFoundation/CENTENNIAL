package rmon.airInterface;

public class AdditionalInfo {
	
	public String interfaceStatusResponse = new String();
	public String currentTransmissionResponse = new String();
	public String TransmissionListResponse = new String();
	public String CurrentTransmissionMode = new String();
	public int ChannelBandwidth = -1;
	public int codeRate = -1;
	public int symbolRateReductionFactor = -1;
	public int modulationScheme = -1;
	public String reason = new String();

}
