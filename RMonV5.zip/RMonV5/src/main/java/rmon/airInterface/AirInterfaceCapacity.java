package rmon.airInterface;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import rmon.common.Configuration;
import rmon.common.RestOperations;
import rmon.common.RmonResponse;
import rmon.database.Connector;
import rmon.database.DataBase;
import rmon.database.LTPLPs;
import rmon.database.LtpAugment;
import rmon.database.WriteToFile;
import rmon.logger.Log;

/*
 * @author : Prathiba Jeevan
 * purpose : calculates the air-interface capacity by using the following steps , 
 * step 1 :	Get the current transmission mode from the air-interface-status, 
 * step 2 : From the air-interface-capacity/transmission-mode-list match the current performance
 * step 3 : get the parameters ChannelBandwidth,codeRate,symbolRateReductionFactor,modulationScheme
 * step 4 : calculate the capacity using the formulae {(ChannelBandwidth) / (symbolRateReductionFactor) * log2(modulationScheme) * (codeRate) / 1.15}
 *
 * Notes  : Units in Kbits/sec
 */

public class AirInterfaceCapacity extends Thread {

	String nodeId = new String();
	String uuid = new String();
	String lpId = new String();
	String connector = new String();
	String vendorId = new String();
	String tab = "\t";

	public AirInterfaceCapacity(String nodeId, String uuid, String lpId) {
		this.nodeId = nodeId;
		this.uuid = uuid;
		this.lpId = lpId;
		updateEquipment();
		updateVendor();

	}

	public void updateEquipment() {
		ArrayList<LtpAugment> LtpAugmentArray = DataBase.ltpAugment.get(nodeId);
		if (LtpAugmentArray != null) {
			Iterator<LtpAugment> iterator = LtpAugmentArray.iterator();
			while (iterator.hasNext()) {
				LtpAugment LtpAugments = iterator.next();
				if (uuid.equals(LtpAugments.uuid)) {
					String connectorId = LtpAugments.connectors;
					ArrayList<Connector> connectorsArray = DataBase.connectors.get(nodeId);
					if (connectorsArray != null) {
						Iterator<Connector> connIterator = connectorsArray.iterator();
						while (connIterator.hasNext()) {
							Connector connect = connIterator.next();
							if (connectorId.equals(connect.uuid)) {
								this.connector = connect.name;
							}
						}
					}
				}
			}
		}
		
		if(this.connector.isEmpty())
		{
			this.connector = "not-defined";
		}
	}

	public void updateVendor() {
		String vendor = DataBase.vendors.get(nodeId);
		if (vendor != null) {
			this.vendorId = vendor;
		}
		if(this.vendorId.isEmpty())
		{
			this.vendorId = "not-defined";
		}
	}

	@Override
	public void run() {
		for (int i = 1; i <= Configuration.iteration; i++) {
			calculateAirInterfaceCapacity(i);
			try {
				Thread.sleep(Configuration.frequency);
			} catch (InterruptedException ex) {
				Log.Error(ex);
			}
		}
	}

	public boolean checkIfInterfaceStatusIsUp(AdditionalInfo additionalInfo) {
		boolean interfaceStatus = false;
		RmonResponse restResponse = RestOperations.getAirInterfaceStatusAttribute(nodeId, uuid, lpId,
				"interface-status");
		if (restResponse == null) {
			additionalInfo.interfaceStatusResponse = "No output received for the request";
			additionalInfo.reason = "No output received while trying to fetch status/InterfaceStatus";
		} else {
			if (restResponse.result.equals("pass")) {
				String status = (String) restResponse.response;
				if (status.contains("INTERFACE_STATUS_TYPE_UP")) {
					interfaceStatus = true;
				}
				additionalInfo.interfaceStatusResponse = Integer.toString(restResponse.responseCode);
			} else {
				additionalInfo.interfaceStatusResponse = "Response code is "
						+ Integer.toString(restResponse.responseCode) + " and error message is "
						+ ((String) restResponse.response).replace("\t", "").replace("\n", "").replace("\r", "").replace(",", ".");
				additionalInfo.reason = "Rest call failure with response code " + restResponse.responseCode + " for status/InterfaceStatus attribute";
			}
		}

		return interfaceStatus;
	}

	public String getCurrentTransmission(AdditionalInfo additionalInfo) {
		String currentTransmission = null;
		RmonResponse restResponse = RestOperations.getAirInterfaceStatusAttribute(nodeId, uuid, lpId,
				"transmission-mode-cur");
		if (restResponse == null) {
			additionalInfo.currentTransmissionResponse = "No output received for the request";
			additionalInfo.reason = "No output received while trying to fetch status/transmission-mode-cur";
		} else {
			if (restResponse.result.equals("pass")) {
				currentTransmission = (String) restResponse.response;
				additionalInfo.currentTransmissionResponse = Integer.toString(restResponse.responseCode);
				additionalInfo.CurrentTransmissionMode = (String)restResponse.response;
			} else {
				additionalInfo.currentTransmissionResponse = "Response code is "
						+ Integer.toString(restResponse.responseCode) + " and error message is "
						+ ((String) restResponse.response).replace("\t", "").replace("\n", "").replace("\r", "").replace(",", ".");
				additionalInfo.reason = "Rest call failure with response code " + restResponse.responseCode + " for status/transmission-mode-cur attribute";
			}
		}
		return currentTransmission;
	}

	public Double calculateCapacity(String currentTransmission, AdditionalInfo additionalInfo) {
		boolean isAvailable = false;
		int ChannelBandwidth = 0;
		int codeRate = 0;
		int symbolRateReductionFactor = 0;
		int modulationScheme = 0;
		RmonResponse restResponse = RestOperations.getAirInterfaceTransmissionModeList(nodeId, uuid, lpId);
		if (restResponse == null) {
			additionalInfo.TransmissionListResponse = "No output received for the request";
			additionalInfo.reason = "No output received while trying to fetch transmission-mode-list";
		} else {
			if (restResponse.result.equals("pass")) {
				JSONArray jsonArray = (JSONArray)restResponse.response;
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject json = jsonArray.getJSONObject(i);
					additionalInfo.TransmissionListResponse = Integer.toString(restResponse.responseCode);
					if (json.getString("transmission-mode-name").equals(currentTransmission)) {
						isAvailable = true;
						if (json.has("channel-bandwidth")) {
							ChannelBandwidth = json.getInt("channel-bandwidth");
							additionalInfo.ChannelBandwidth = ChannelBandwidth;
						} else {
							Log.info("channel-bandwidth for the nodeid=" + nodeId + "uuid=" + uuid
									+ " is not available");
							additionalInfo.reason = "channel-bandwidth attribute is not available";
							return null;
						}
						if (json.has("code-rate")) {
							codeRate = json.getInt("code-rate");
							additionalInfo.codeRate = codeRate;
						} else {
							Log.info("code-rate for the nodeid=" + nodeId + "uuid=" + uuid + " is not available");
							additionalInfo.reason = "code-rate attribute is not available";
							return null;
						}
						if (json.has("symbol-rate-reduction-factor")) {
							symbolRateReductionFactor = json.getInt("symbol-rate-reduction-factor");
							additionalInfo.symbolRateReductionFactor = symbolRateReductionFactor;
						} else {
							Log.info("symbol-rate-reduction-factor for the nodeid=" + nodeId + "uuid=" + uuid
									+ " is not available");
							additionalInfo.reason = "symbol-rate-reduction-factor attribute is not available";
							return null;
						}
						if (json.has("modulation-scheme")) {
							modulationScheme = json.getInt("modulation-scheme");
							additionalInfo.modulationScheme = modulationScheme;
						} else {
							Log.info("modulation-scheme for the nodeid=" + nodeId + "uuid=" + uuid
									+ " is not available");
							additionalInfo.reason = "modulation-scheme attribute is not available";
							return null;
						}
					}
				}
			}else
			{
				additionalInfo.TransmissionListResponse = "Response code is "
						+ Integer.toString(restResponse.responseCode) + " and error message is "
						+ ((String) restResponse.response).replace("\t", "").replace("\n", "").replace("\r", "").replace(",", ".");
				additionalInfo.reason = "Unable to retrieve the transmission-mode-list";
			}
		}
		if(isAvailable)
		{
		double result = calculation(ChannelBandwidth, codeRate, symbolRateReductionFactor, modulationScheme,additionalInfo);
		return result;
		}else
		{
			additionalInfo.reason = "No match identified for the current transmission mode "+currentTransmission+" in the retrieved capability/transmission-mode-list";
		}
		return null;
	}

	public Double calculation(int ChannelBandwidth, int codeRate, int symbolRateReductionFactor, int modulationScheme,AdditionalInfo additionalInfo) {

		try {
			int log2valueofmodulationScheme = log2(modulationScheme);
			double codeRatePercent = new Double(codeRate) / 100;
			double value = ChannelBandwidth / symbolRateReductionFactor * log2valueofmodulationScheme * codeRatePercent
					/ 1.15;
			return value;
		} catch (Exception ex) {
			additionalInfo.reason = "problem in the final capacity calculation";
			Log.Error("Issues in the capacity calculation for the nodeId=" + nodeId + "uuid=" + uuid);
			Log.Error(ex);
		}
		return null;
	}

	public static int log2(int modulationScheme) {
		int count = 0;
		for (int i = modulationScheme; i > 1; i = i / 2) {
			count++;
		}
		return count;
	}

	// "Iteration","Node id","Connection Status","Vendor","eqpt","uuid","Interface
	// Type", "Date","Interface-Status","Capacity" ,"Response Code","Additional
	// Info"
	public void calculateAirInterfaceCapacity(int Iteration) {
		AdditionalInfo additionalInfo = new AdditionalInfo();
		if (checkIfInterfaceStatusIsUp(additionalInfo)) {
			String currentTransmissionMode = getCurrentTransmission(additionalInfo);
			if (currentTransmissionMode != null && !currentTransmissionMode.isEmpty()) {
				Double capacity = calculateCapacity(currentTransmissionMode,additionalInfo);
				if (capacity != null) {
					prepareOutput(Iteration, nodeId, "UP", vendorId, connector, uuid, "Air-interface", new Date(),capacity, additionalInfo);
				} else {
					prepareOutput(Iteration, nodeId, "UP", vendorId, connector, uuid, "Air-interface", new Date(),"not-calculated",additionalInfo);
				}
			} else {
				prepareOutput(Iteration, nodeId, "UP", vendorId, connector, uuid, "Air-interface", new Date(),"not-calculated",additionalInfo);
			}
		} else {
			additionalInfo.reason = "Interface status is down";
			prepareOutput(Iteration, nodeId, "DOWN", vendorId, connector, uuid, "Air-interface", new Date(), "not-calculated", additionalInfo);
		}

	}

	public void prepareOutput(int iteration, String nodeId, String InterfaceStatus, String vendorId, String connector,
			String uuid, String interfaceType, Date date, Double capacity, AdditionalInfo additionalInfo) {
		WriteToFile output = new WriteToFile(Configuration.airInterfaceReport);
		String line = iteration + tab + nodeId + tab + InterfaceStatus + tab + vendorId + tab + connector + tab + uuid
				+ tab + interfaceType + tab + date + tab + capacity + tab + additionalInfo.reason + tab + additionalInfo.interfaceStatusResponse
				+ tab + additionalInfo.currentTransmissionResponse + tab + additionalInfo.TransmissionListResponse + tab + additionalInfo.CurrentTransmissionMode
				+ tab + additionalInfo.ChannelBandwidth + tab + additionalInfo.codeRate + tab + additionalInfo.modulationScheme 
				+ tab + additionalInfo.symbolRateReductionFactor;
		output.write(line);
	}
	
	public void prepareOutput(int iteration, String nodeId, String InterfaceStatus, String vendorId, String connector,
			String uuid, String interfaceType, Date date, String capacity, AdditionalInfo additionalInfo) {
		WriteToFile output = new WriteToFile(Configuration.airInterfaceReport);
		String line = iteration + tab + nodeId + tab + InterfaceStatus + tab + vendorId + tab + connector + tab + uuid
				+ tab + interfaceType + tab + date + tab + capacity + tab + additionalInfo.reason + tab + additionalInfo.interfaceStatusResponse
				+ tab + additionalInfo.currentTransmissionResponse + tab + additionalInfo.TransmissionListResponse + tab + additionalInfo.CurrentTransmissionMode
				+ tab + additionalInfo.ChannelBandwidth + tab + additionalInfo.codeRate + tab + additionalInfo.modulationScheme 
				+ tab + additionalInfo.symbolRateReductionFactor;
		output.write(line);
	}

}
