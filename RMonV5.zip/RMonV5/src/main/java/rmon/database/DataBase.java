package rmon.database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DataBase {
	
	public static Map<String, ArrayList<LTPLPs>> LTPLPs = new HashMap<String, ArrayList<LTPLPs>>();
	public static Map<String, ArrayList<ServerClientLTPs>> ServerClientLTPs = new HashMap<String, ArrayList<ServerClientLTPs>>();
	public static Map<String,String> vendors = new HashMap<String,String>();
	public static Map<String,ArrayList<LtpAugment>> ltpAugment = new HashMap<String,ArrayList<LtpAugment>>();
	public static Map<String,ArrayList<Equipment>> equipments = new HashMap<String,ArrayList<Equipment>>();
	public static Map<String,ArrayList<Connector>> connectors = new HashMap<String,ArrayList<Connector>>();
}
