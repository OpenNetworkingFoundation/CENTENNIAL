package rmon.database;

import java.io.File;

/*
 * steps to calculate the vendor ID
 * step 1 : get the airinterface uuid
 * step 2 : check if the air-interface is having ltp-augment/equipment
 * step 3 : check the equivalent equipment uuid in the Equipment class
 * step 4 : get the manufacturer details
 * 
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import org.json.JSONArray;

import rmon.RMonProcess;
import rmon.common.Configuration;
import rmon.logger.Log;

public class Vendor {

	String nodeId;
	String vendorName;
	public static ArrayList<String> vendorTypes = new ArrayList<String>();
	public static String file = Configuration.DBPath + File.separator + "Vendors";

	public Vendor(String nodeId, String vendorName) {
		this.nodeId = nodeId;
		this.vendorName = vendorName;
	}

	public static void loadFromDB(String nodeId,RMonProcess process) {
		String manufacturerName = "not-defined";
		try {
			File vendorFile = new File(Configuration.DBPath + File.separator + "Vendors");
			if (vendorFile.exists()) {

				Scanner scan = new Scanner(vendorFile);
				while (scan.hasNext()) {
					String line = scan.nextLine();
					String[] details = line.split(":::");
					if (details[0].equals(nodeId)) {
						manufacturerName = details[1];
						DataBase.vendors.put(nodeId, manufacturerName);
					}
				}
				scan.close();
			}
		} catch (Exception ex) {
			Log.Error("exception in retrieving vendorNames from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
		if (manufacturerName.equals("not-defined")) {
			loadFromController(nodeId,process);
		}
	}

	public static void loadFromController(String nodeId,RMonProcess process) {
		try {
		String manufacturerName = new String();
		WriteToFile vendorWriter = new WriteToFile(Configuration.DBPath + File.separator + "Vendors");
		ArrayList<String> uuids = LTPLPs.getLTPs(nodeId);
		if (uuids != null) {
			Iterator<String> iterator = uuids.iterator();
			while (iterator.hasNext()) {
				String uuid = iterator.next();
				String protocolName = LTPLPs.getProtocalName(nodeId, uuid);
				if (protocolName.equals(Configuration.airInterface)) {
					LtpAugment ltpAugment = LtpAugment.getLtpAugment(nodeId, uuid);
					if (ltpAugment != null) {
						JSONArray ltpEquipmentArray = ltpAugment.equipment;
						for (int i = 0; i < ltpEquipmentArray.length(); i++) {
							String manufacturer = Equipment.getEquipmentDetailsForLTPAugment(nodeId,
									ltpEquipmentArray.get(i).toString());

							Iterator<String> vendorIter = vendorTypes.iterator();
							while (vendorIter.hasNext()) {
								if (manufacturer.contains(vendorIter.next())) {
									manufacturerName = manufacturer;
								}
							}

						}

					}
				}
			}
		}
		DataBase.vendors.put(nodeId, manufacturerName);
		vendorWriter.write(nodeId + ":::" + manufacturerName);
		}catch(Exception ex)
		{
			Log.Error("exception in processing the vendorNames from file" + nodeId);
			Log.Error(ex);
			process.DBStatus = "fail";
		}
	}
		

}
