package rmon.logger;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;


public class Log {
	
	public static Logger logger = Logger.getLogger(Log.class);
	
	public static void Error(Exception ex)
	{
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		logger.error(sw);
	}
	
	public static void Error(String message)
	{
		logger.error(message);
	}
	
	public static void info(Exception ex)
	{
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		logger.info(sw);
	}
	
	public static void info(String message)
	{
		logger.info(message);
	}
	
	public static void warning(Exception ex)
	{
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		logger.warn(sw);
	}
	
	public static void warning(String message)
	{
		logger.warn(message);
	}

}
