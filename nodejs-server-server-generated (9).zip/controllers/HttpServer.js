'use strict';

var utils = require('../utils/writer.js');
var HttpServer = require('../service/HttpServerService');

module.exports.getHttpServerApplicationName = function getHttpServerApplicationName (req, res, next, uuid, lid) {
  HttpServer.getHttpServerApplicationName(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
