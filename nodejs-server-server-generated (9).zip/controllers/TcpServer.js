'use strict';

var utils = require('../utils/writer.js');
var TcpServer = require('../service/TcpServerService');

module.exports.getTcpServerLocalAddress = function getTcpServerLocalAddress (req, res, next, uuid, lid) {
  TcpServer.getTcpServerLocalAddress(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getTcpServerLocalPort = function getTcpServerLocalPort (req, res, next, uuid, lid) {
  TcpServer.getTcpServerLocalPort(uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putTcpServerLocalAddress = function putTcpServerLocalAddress (req, res, next, body, uuid, lid) {
  TcpServer.putTcpServerLocalAddress(body, uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putTcpServerLocalPort = function putTcpServerLocalPort (req, res, next, body, uuid, lid) {
  TcpServer.putTcpServerLocalPort(body, uuid, lid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
