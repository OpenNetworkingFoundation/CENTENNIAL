'use strict';


/**
 * Returns administrative information
 *
 * returns inline_response_200_3
 **/
exports.informAboutApplication = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "applicationName" : "CurrentController",
  "applicationPurpose" : "Provides first part of the RESTCONF request to other applications.",
  "dataUpdatePeriod" : "manual",
  "lifeCycleState" : "Experimental",
  "ownerName" : "Thorsten Heinze",
  "ownerEmailAddress" : "Thorsten.Heinze@telefonica.com"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns administrative information for generic representation
 *
 * returns List
 **/
exports.informAboutApplicationInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  }, {
    "fieldName" : "applicationPurpose",
    "value" : "Provides first part of the RESTCONF request to other applications.",
    "datatype" : "String"
  }, {
    "fieldName" : "dataUpdatePeriod",
    "value" : "manual",
    "datatype" : "String"
  }, {
    "fieldName" : "lifeCycleState",
    "value" : "Experimental",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerName",
    "value" : "Thorsten Heinze",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerEmailAddress",
    "value" : "Thorsten.Heinze@telefonica.com",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "label" : "Release History",
    "request" : "https://[localAddress]:[LocalPort]/v1/informAboutReleaseHistoryInGenericRepresentation"
  }, {
    "label" : "API Documentation",
    "request" : "https://[localAddress]:[LocalPort]/v1/informAboutApi"
  } ]
}, {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  }, {
    "fieldName" : "applicationPurpose",
    "value" : "Provides first part of the RESTCONF request to other applications.",
    "datatype" : "String"
  }, {
    "fieldName" : "dataUpdatePeriod",
    "value" : "manual",
    "datatype" : "String"
  }, {
    "fieldName" : "lifeCycleState",
    "value" : "Experimental",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerName",
    "value" : "Thorsten Heinze",
    "datatype" : "String"
  }, {
    "fieldName" : "ownerEmailAddress",
    "value" : "Thorsten.Heinze@telefonica.com",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "label" : "Release History",
    "request" : "https://[localAddress]:[LocalPort]/v1/informAboutReleaseHistoryInGenericRepresentation"
  }, {
    "label" : "API Documentation",
    "request" : "https://[localAddress]:[LocalPort]/v1/informAboutApi"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns release history
 *
 * returns List
 **/
exports.informAboutReleaseHistory = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "revisionNumber" : "0.0.1",
  "releaseDate" : "11.05.2021",
  "changes" : "Initial version"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns release history for generic representation
 *
 * returns List
 **/
exports.informAboutReleaseHistoryInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "revisionNumber",
    "value" : "0.0.1",
    "datatype" : "String"
  }, {
    "fieldName" : "releaseDate",
    "value" : "11.05.2021",
    "datatype" : "String"
  }, {
    "fieldName" : "changes",
    "value" : "Initial version",
    "datatype" : "String"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

