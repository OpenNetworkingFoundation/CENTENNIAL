'use strict';


/**
 * Returns UUIDs and LIDs together with layer protocol name
 *
 * fields String 
 * returns inline_response_200_8
 **/
exports.getControlConstruct = function(fields) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "core-model-1-4:control-construct" : {
    "logical-termination-point" : [ {
      "layer-protocol" : [ {
        "local-id" : "LP-HTTP-C-27",
        "layer-protocol-name" : "http-client-interface-1-0:LAYER_PROTOCOL_NAME_TYPE_HTTP_LAYER"
      }, {
        "local-id" : "LP-HTTP-C-27",
        "layer-protocol-name" : "http-client-interface-1-0:LAYER_PROTOCOL_NAME_TYPE_HTTP_LAYER"
      } ],
      "uuid" : "LTP-HTTP-C-27"
    }, {
      "layer-protocol" : [ {
        "local-id" : "LP-HTTP-C-27",
        "layer-protocol-name" : "http-client-interface-1-0:LAYER_PROTOCOL_NAME_TYPE_HTTP_LAYER"
      }, {
        "local-id" : "LP-HTTP-C-27",
        "layer-protocol-name" : "http-client-interface-1-0:LAYER_PROTOCOL_NAME_TYPE_HTTP_LAYER"
      } ],
      "uuid" : "LTP-HTTP-C-27"
    } ]
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

