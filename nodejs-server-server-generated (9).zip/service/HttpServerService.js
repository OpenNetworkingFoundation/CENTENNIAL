'use strict';


/**
 * Returns application name
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_12
 **/
exports.getHttpServerApplicationName = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "http-server-interface-1-0:application-name" : "http-server-interface-1-0:application-name"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

