'use strict';


/**
 * Returns String controllerIp:restconfPort
 *
 * returns inline_response_200
 **/
exports.provideCurrentController = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "currentController" : "10.118.125.157:8443"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns String controllerIp:restconfPort in generic representation
 *
 * returns List
 **/
exports.provideCurrentControllerInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "currentController",
    "value" : "10.118.125.157:8443",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "request" : "request",
    "label" : "label"
  }, {
    "request" : "request",
    "label" : "label"
  } ]
}, {
  "responseValueList" : [ {
    "fieldName" : "currentController",
    "value" : "10.118.125.157:8443",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "request" : "request",
    "label" : "label"
  }, {
    "request" : "request",
    "label" : "label"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Starts application in generic representation
 *
 * returns List
 **/
exports.startApplicationInGenericRepresentation = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "label" : "Provide ControllerIp:RestconfPort",
    "request" : "https://[localAddress]:[localPort]/v1/provideCurrentControllerInGenericRepresentation"
  } ]
}, {
  "responseValueList" : [ {
    "fieldName" : "applicationName",
    "value" : "CurrentController",
    "datatype" : "String"
  } ],
  "inputValueList" : [ {
    "unit" : "unit",
    "fieldName" : "fieldName"
  }, {
    "unit" : "unit",
    "fieldName" : "fieldName"
  } ],
  "consequentActionList" : [ {
    "label" : "Provide ControllerIp:RestconfPort",
    "request" : "https://[localAddress]:[localPort]/v1/provideCurrentControllerInGenericRepresentation"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

