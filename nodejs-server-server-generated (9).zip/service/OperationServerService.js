'use strict';


/**
 * Returns the configured current controller
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_7
 **/
exports.getOperationServerCurrentController = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "operation-server-interface-1-0:current-controller" : "10.118.125.157:8443"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns the configured life cycle state of the operation
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_10
 **/
exports.getOperationServerLifeCycleState = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "operation-server-interface-1-0:life-cycle-state" : "operation-server-interface-1-0:LIFE_CYCLE_STATE_TYPE_EXPERIMENTAL"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns key for connecting
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_11
 **/
exports.getOperationServerOperationKey = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "operation-server-interface-1-0:operation-key" : "Operation key not yet provided."
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns operation name
 *
 * uuid String 
 * lid String 
 * returns inline_response_200_9
 **/
exports.getOperationServerOperationName = function(uuid,lid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "operation-server-interface-1-0:operation-name" : "operation-server-interface-1-0:operation-name"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Configures current controller
 *
 * body Body 
 * uuid String 
 * lid String 
 * no response value expected for this operation
 **/
exports.putOperationServerCurrentController = function(body,uuid,lid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Configures life cycle state
 *
 * body Body_1 
 * uuid String 
 * lid String 
 * no response value expected for this operation
 **/
exports.putOperationServerLifeCycleState = function(body,uuid,lid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Changes key for connecting
 *
 * body Body_2 
 * uuid String 
 * lid String 
 * no response value expected for this operation
 **/
exports.putOperationServerOperationKey = function(body,uuid,lid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

